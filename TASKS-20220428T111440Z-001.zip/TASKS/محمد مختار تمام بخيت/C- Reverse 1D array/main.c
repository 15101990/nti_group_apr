#include "APP_STD_Types.h"
#include <stdio.h>
#include <stdlib.h>

void REVERSE_1D_ARRAY (uint32 *loc_U32_PTR_ARRAY_DATA);
void ASKING_to (uint32 *loc_U32_PTR_ARRAY_DATA);

#define ARRAY_SIZE			10
#define ARRAY_INDEX_SHIFT	1

int main (void)
{	
	uint32 Array [ARRAY_SIZE] = {0};
	
	ASKING_to(Array);
	REVERSE_1D_ARRAY(Array);
	
	uint8 i =0;
	for(i =0; i < ARRAY_SIZE; i++)
	{
        printf("Element [%d] -> %d\n",i+1, Array[i]);
    }	
}

void ASKING_to (uint32 *loc_U32_PTR_ARRAY_DATA)
{
	uint8 i =0;
	uint32 loc_U32_Arr_Value =0;
	for(i =0; i < ARRAY_SIZE; i++)
	{
        printf("Enter element [%d] -> ",i+1);
		scanf("%d",&loc_U32_Arr_Value);
		loc_U32_PTR_ARRAY_DATA[i] = loc_U32_Arr_Value;
	}
}
void REVERSE_1D_ARRAY (uint32 *loc_U32_PTR_ARRAY_DATA) // eng. Helmy tried REVERSE_1D_ARRAY (uint32 loc_U32_PTR_ARRAY_DATA[]) == pointer
{
	uint8 i = 0;
	uint32 loc_U32_Holder =0;
    for(i =0; i <ARRAY_SIZE/2; i++)
	{
        loc_U32_Holder = loc_U32_PTR_ARRAY_DATA[i];
        loc_U32_PTR_ARRAY_DATA[i] = loc_U32_PTR_ARRAY_DATA[ARRAY_SIZE-i-ARRAY_INDEX_SHIFT];
        loc_U32_PTR_ARRAY_DATA[ARRAY_SIZE-i-ARRAY_INDEX_SHIFT] = loc_U32_Holder;
    }
}