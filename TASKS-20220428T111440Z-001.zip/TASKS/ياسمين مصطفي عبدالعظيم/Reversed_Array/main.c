/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

#define SIZE 5

void reverse(int a[] );

int main()
{
    int arr[SIZE];
    int i ;
    for(i=0;i<=SIZE;i++)
    {
        scanf("%d",&arr[i]);
    }
     reverse(arr);
    
     for(i=0;i<=SIZE;i++)
    {
        printf("element[%d] = %d",i,arr[i]);
    }
}
    
    void reverse(int a[])
    {
        int temp;
        int j =0 ;
        
        for(j=0;j<SIZE/2;j++)
        {
            temp=a[j];
            a[j]=a[SIZE-j-1];
            a[SIZE-j-1]=temp;
        }
       
    }
    

