/*
 * P_Button.c
 *
 * Created: 4/15/2022 2:35:20 PM
 *  Author: yasmine mostafa
 */ 

#include "P_Button.h"

void H_PushButtonInit(uint8 P_B)
{
	switch(P_B)
	{
		case P_B1:
		M_PinMode(P_Button_Pin1,INPUT);
		M_PinPullUp(P_Button_Pin1,ENABLE);
		break;
		case P_B2:
		M_PinMode(P_Button_Pin2,INPUT);
		M_PinPullUp(P_Button_Pin2,ENABLE);
		break;	
		case P_B3:
		M_PinMode(P_Button_Pin3,INPUT);
		M_PinPullUp(P_Button_Pin3,ENABLE);
		break;
		case P_B4:
		M_PinMode(P_Button_Pin4,INPUT);
		M_PinPullUp(P_Button_Pin4,ENABLE);
		break;
		default:
		break;

	}
	
	
}

uint8 H_PushButtonRead(uint8 P_B)
{
	uint8 reading = 0;
	
	switch(P_B)
	{
		case P_B1:
		reading = M_PinRead(P_Button_Pin2);
		break;
		case P_B2:
		reading = M_PinRead(P_Button_Pin2);
		break;
		case P_B3:
		reading = M_PinRead(P_Button_Pin3);
		break;
		case P_B4:
		reading = M_PinRead(P_Button_Pin4);
		break;
		default:
		break;
	}
	return reading;	
}
