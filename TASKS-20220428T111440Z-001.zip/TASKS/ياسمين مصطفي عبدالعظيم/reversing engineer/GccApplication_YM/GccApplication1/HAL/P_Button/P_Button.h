/*
 * P_Button.h
 *
 * Created: 4/15/2022 2:35:36 PM
 *  Author: yasmine mostafa
 */ 


#ifndef P_BUTTON_H_
#define P_BUTTON_H_

#include "STD.h"
#include "P_Button_CFG.h"
#include "DIO.h"


void H_PushButtonInit(uint8);
uint8 H_PushButtonRead(uint8);

#define P_B1	1
#define P_B2	2
#define P_B3	3
#define P_B4	4

#define    PRESSED         0
#define    RELEASED        1

#endif /* P_BUTTON_H_ */