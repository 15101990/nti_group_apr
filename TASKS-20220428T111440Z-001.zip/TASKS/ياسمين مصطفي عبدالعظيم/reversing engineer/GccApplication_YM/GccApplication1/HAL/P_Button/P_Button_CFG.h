/*
 * P_Button_CFG.h
 *
 * Created: 4/15/2022 2:35:49 PM
 *  Author: yasmine mostafa
 */ 


#ifndef P_BUTTON_CFG_H_
#define P_BUTTON_CFG_H_

#define P_Button_Pin1	PD2
#define P_Button_Pin2	PD3
#define P_Button_Pin3	PD4
#define P_Button_Pin4	PD5




#endif /* P_BUTTON_CFG_H_ */