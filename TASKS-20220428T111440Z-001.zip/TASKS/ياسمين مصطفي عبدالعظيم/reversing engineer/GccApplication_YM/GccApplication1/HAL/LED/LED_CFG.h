/*
 * LED_CFG.h
 *
 * Created: 4/8/2022 12:21:58 AM
 *  Author: yasmine mostafa
 */ 


#ifndef LED_CFG_H_
#define LED_CFG_H_

#define RedLed		PC0
#define GreenLed	PC1
#define BlueLed		PC2



#endif /* LED_CFG_H_ */