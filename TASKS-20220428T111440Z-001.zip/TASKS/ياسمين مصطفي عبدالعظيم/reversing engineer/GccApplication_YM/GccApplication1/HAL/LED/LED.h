/*
 * LED.h
 *
 * Created: 4/8/2022 12:21:31 AM
 *  Author: yasmine mostafa
 */ 


#ifndef LED_H_
#define LED_H_

#include "STD.h"
#include "LED_CFG.h"

void H_LedInit(uint8);
void H_LedOn(uint8);
void H_LedOff(uint8);
void H_LedTog(uint8);
void H_LedBlink(uint8);

#define R_LED	1
#define G_LED	2
#define B_LED	3




#endif /* LED_H_ */