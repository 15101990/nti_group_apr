/*
 * LED.c
 *
 * Created: 4/8/2022 12:21:44 AM
 *  Author: yasmine mostafa
 */ 


#include "LED_CFG.h"
#include "LED.h"
#include "DIO.h"

#define F_CPU  16000000UL
#include <util/delay.h>

void H_LedInit(uint8 Led)
{
	switch(Led)
	{
		case R_LED:
		M_PinMode(RedLed,OUTPUT);
		break;
		
		case G_LED:
		M_PinMode(GreenLed,OUTPUT);
		break;
		
		case B_LED:
		M_PinMode(BlueLed,OUTPUT);
		break;
		
		default:
		break;
	}
	
}
void H_LedOn(uint8 Led)
{
	switch(Led)
	{
		case R_LED:
		M_PinWrite(RedLed,HIGH);
		break;
		
		case G_LED:
		M_PinWrite(GreenLed,HIGH);
		break;
		
		case B_LED:
		M_PinWrite(BlueLed,HIGH);
		break;
		
		default:
		break;
	}
	
}

void H_LedOff(uint8 Led)
{
	switch(Led)
	{
		case R_LED:
		M_PinWrite(RedLed,LOW);
		break;
		
		case G_LED:
		M_PinWrite(GreenLed,LOW);
		break;
		
		case B_LED:
		M_PinWrite(BlueLed,LOW);
		break;
		
		default:
		break;
	}
}

void H_LedTog(uint8 Led)
{
	switch(Led)
	{
		case R_LED:
		M_PinTog(RedLed);
		break;
		
		case G_LED:
		M_PinTog(GreenLed);
		break;
		
		case B_LED:
		M_PinTog(BlueLed);
		break;
		
		default:
		break;
	}
	
}

void H_LedBlink(uint8 Led)
{
	switch(Led)
	{
		case R_LED:
		M_PinWrite(RedLed,HIGH);
		_delay_ms(5);
		M_PinWrite(RedLed,LOW);
		break;
		
		case G_LED:
		M_PinWrite(GreenLed,HIGH);
		_delay_ms(5);
		M_PinWrite(GreenLed,LOW);
		break;
		
		case B_LED:
		M_PinWrite(BlueLed,HIGH);
		_delay_ms(5);
		M_PinWrite(BlueLed,LOW);
		break;
		
		default:
		break;
	}
}

