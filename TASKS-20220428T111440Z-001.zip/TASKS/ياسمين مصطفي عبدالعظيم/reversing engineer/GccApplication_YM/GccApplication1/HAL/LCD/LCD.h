/*
 * LCD.h
 *
 * Created: 4/16/2022 3:19:05 PM
 *  Author: yasmine mostafa
 */ 


#ifndef LCD_H_
#define LCD_H_

#include "LCD_CFG.h"
#include "STD.h"
#include "DIO.h"
#include "REG.h"
# define F_CPU 16000000UL
#include <util/delay.h>

void H_LcdInit(void);
void H_LcdWriteCommand(uint8);
void H_LcdWriteCharacter(uint8);
void H_LcdWriteString(uint8*);
void H_LcdWriteNumber(float_64);
void H_LcdClear(void);
void H_LcdGoTo(uint8,uint8);
void H_Lcd_Stop_Watch_Display(uint8,uint8 ,uint8);

#define _8_BIT_MODE		8
#define _4_BIT_MODE		4

#endif /* LCD_H_ */