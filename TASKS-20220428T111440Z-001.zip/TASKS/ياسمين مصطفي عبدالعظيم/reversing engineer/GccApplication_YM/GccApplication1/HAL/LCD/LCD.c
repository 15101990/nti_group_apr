/*
 * LCD.c
 *
 * Created: 4/16/2022 3:19:28 PM
 *  Author: yasmine mostafa
 */ 

#include "LCD_CFG.h"
#include "LCD.h"


void H_LcdInit(void)
{
	M_PinMode(LCD_RS,OUTPUT);
	M_PinMode(LCD_RW,OUTPUT);
	M_PinMode(LCD_E,OUTPUT);
	
	#if		LCD_MODE	==	_8_BIT_MODE

	M_PinMode(LCD_Pin_0,OUTPUT);
	M_PinMode(LCD_Pin_1,OUTPUT);
	M_PinMode(LCD_Pin_2,OUTPUT);
	M_PinMode(LCD_Pin_3,OUTPUT);
	M_PinMode(LCD_Pin_4,OUTPUT);
	M_PinMode(LCD_Pin_5,OUTPUT);
	M_PinMode(LCD_Pin_6,OUTPUT);
	M_PinMode(LCD_Pin_7,OUTPUT);
	
	
	
	_delay_ms(500); // to leave time to LCD's MC power up and startup code need time to call main

	// commands to activate LCD 
	
	H_LcdWriteCommand(0x38); // to activate 8-bit mode
	H_LcdWriteCommand(0x0C); //display on
	H_LcdWriteCommand(0x02); // to return home
	H_LcdWriteCommand(0x06); // to display from left to right
	H_LcdWriteCommand(0x01); // to clear LCD
	
	
	#elif  LCD_MODE		==	_4_BIT_MODE
	
		M_PinMode(LCD_Pin_4,OUTPUT);
		M_PinMode(LCD_Pin_5,OUTPUT);
		M_PinMode(LCD_Pin_6,OUTPUT);
		M_PinMode(LCD_Pin_7,OUTPUT);
		
		_delay_ms(500); // to leave time to LCD's MC power up and startup code need time to call main

		// commands to activate LCD
		
		H_LcdWriteCommand(0x33); // to activate 4-bit mode
		H_LcdWriteCommand(0x32); // to activate 4-bit mode
		H_LcdWriteCommand(0x28); // to activate 4-bit mode
		H_LcdWriteCommand(0x0C); //display on
		H_LcdWriteCommand(0x02); // to return home
		H_LcdWriteCommand(0x06); // to display from left to right
		H_LcdWriteCommand(0x01); // to clear LCD
		
		#endif
}

void H_LcdWriteCommand(uint8 local_command)
{
	M_PinWrite(LCD_RS,LOW); // to set RS for select command register
	M_PinWrite(LCD_RW,LOW); // to write 
	
	#if		LCD_MODE	==	_8_BIT_MODE
	LCD_DATA_PORT = local_command ; // write command at portA
	
	M_PinWrite(LCD_E,HIGH); 
	_delay_ms(1); 
	M_PinWrite(LCD_E,LOW);
	_delay_ms(5);
	
	#elif	LCD_MODE	==	_4_BIT_MODE
	LCD_DATA_PORT = ((local_command  & 0b11110000) | (LCD_DATA_PORT & 0b00001111)); // write command at portA
	
	M_PinWrite(LCD_E,HIGH);
	_delay_ms(1);
	M_PinWrite(LCD_E,LOW);
	_delay_ms(5);
	
	LCD_DATA_PORT = ((local_command  << 4 ) | (LCD_DATA_PORT & 0b00001111)); // write command at portA
	
	M_PinWrite(LCD_E,HIGH);
	_delay_ms(1);
	M_PinWrite(LCD_E,LOW);
	_delay_ms(5);
	#endif
}
void H_LcdWriteCharacter(uint8 local_character)
{
	M_PinWrite(LCD_RS,HIGH); // to set RS for select DATA register
	M_PinWrite(LCD_RW,LOW); // to write data
	
	#if LCD_MODE	==	_8_BIT_MODE
	LCD_DATA_PORT = local_character ; // write data at portA to send to LCD
		
	M_PinWrite(LCD_E,HIGH);
	_delay_ms(1);
	M_PinWrite(LCD_E,LOW);
	_delay_ms(5);
	
	
	
	#elif	LCD_MODE	==	_4_BIT_MODE
	LCD_DATA_PORT = ((local_character & 0b11110000) | (LCD_DATA_PORT & 0b00001111)); // write character at portA
	
	M_PinWrite(LCD_E,HIGH);
	_delay_ms(1);
	M_PinWrite(LCD_E,LOW);
	_delay_ms(5);
	
	LCD_DATA_PORT = ((local_character  << 4 ) | (LCD_DATA_PORT & 0b00001111)); // write chracter at portA
	
	M_PinWrite(LCD_E,HIGH);
	_delay_ms(1);
	M_PinWrite(LCD_E,LOW);
	_delay_ms(5);
	#endif
	
}

void H_LcdWriteString(uint8* local_ptr)
{
	uint8 local_counter = 0;
	while(local_ptr[local_counter]!= '\0')
	{
		H_LcdWriteCharacter(local_ptr[local_counter]);
		local_counter++;
	
	}
}
void H_LcdWriteNumber(float_64 Local_Number)
{
	uint8 Local_arr[10] = {0};
	sint8 Local_counter = 0 ;
	sint32 Local_Number_copy = Local_Number;
	if (Local_Number_copy == 0)
	{
		H_LcdWriteCharacter('0');
	}
	else if(Local_Number_copy < 0)
	{
		H_LcdWriteCharacter('-');
		Local_Number_copy = Local_Number_copy * (-1);
		
	}
	
	while (Local_Number_copy != 0)
	{
		Local_arr[Local_counter] = Local_Number_copy % 10 ;
		Local_counter ++ ;
		Local_Number_copy = Local_Number_copy /10 ;
		
	}
	Local_counter--;
	
	// for print numbers
	while(Local_counter >= 0)
	{
		H_LcdWriteCharacter(Local_arr[Local_counter] + '0');
		Local_counter-- ;
	}
	
	
	
}

	


void H_LcdClear(void)
{
	H_LcdWriteCommand(0x01);
}

void H_LcdGoTo(uint8 Local_Row,uint8 Local_Col)
{
		uint8 arr[2] = {0x80,0xC0};
		H_LcdWriteCommand(arr[Local_Row]+Local_Col);
		
		
		
}

void H_Lcd_Stop_Watch_Display(uint8 second,uint8 minute,uint8 hour)
{
	H_LcdGoTo(0,5);
	 if (hour < 10 )
	 {
		 H_LcdWriteCharacter('0');
	 }
	 H_LcdWriteNumber(hour);
	 H_LcdWriteCharacter(':');

	 if (minute < 10 )
	 {
		 H_LcdWriteCharacter('0');
	 }
	 H_LcdWriteNumber(minute);
	 H_LcdWriteCharacter(':');
	 
	if (second < 10  )
	{
		H_LcdWriteCharacter('0');
	}
	H_LcdWriteNumber(second);
	
	
}
