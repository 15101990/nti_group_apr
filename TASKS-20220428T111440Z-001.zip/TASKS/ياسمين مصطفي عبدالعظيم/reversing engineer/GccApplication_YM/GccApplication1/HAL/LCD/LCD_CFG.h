/*
 * LCD_CFG.h
 *
 * Created: 4/16/2022 3:19:17 PM
 *  Author: yasmine mostafa
 */ 


#ifndef LCD_CFG_H_
#define LCD_CFG_H_


#include "DIO.h"
#include "REG.h"

#define LCD_DATA_PORT	PORTA

#define LCD_Pin_0	PA0
#define LCD_Pin_1	PA1
#define LCD_Pin_2	PA2
#define LCD_Pin_3	PA3
#define LCD_Pin_4	PA4
#define LCD_Pin_5	PA5
#define LCD_Pin_6	PA6
#define LCD_Pin_7	PA7

#define LCD_RS		PB1
#define LCD_RW		PB3
#define LCD_E		PB2

//LCD_MODE options --> [_8_BIT_MODE , _4_BIT_MODE]

#define LCD_MODE	_4_BIT_MODE


#endif /* LCD_CFG_H_ */