/*
 * Buzzer_CFG.h
 *
 * Created: 4/16/2022 3:17:27 PM
 *  Author: yasmine mostafa
 */ 


#ifndef BUZZER_CFG_H_
#define BUZZER_CFG_H_



#define Buzzer_Pin    PC5



#endif /* BUZZER_CFG_H_ */