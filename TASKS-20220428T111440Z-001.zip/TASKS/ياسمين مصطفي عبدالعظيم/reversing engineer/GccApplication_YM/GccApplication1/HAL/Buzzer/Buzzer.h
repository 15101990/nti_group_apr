/*
 * Buzzer.h
 *
 * Created: 4/16/2022 3:17:37 PM
 *  Author: yasmine mostafa
 */ 


#ifndef BUZZER_H_
#define BUZZER_H_


#include "STD.h"
#include "Buzzer_CFG.h"
#include "DIO.h"

void H_BuzzerInit(void);
void H_BuzzerOn(void);
void H_BuzzerOff(void);
void H_BuzzerOnce(void);
void H_BuzzerTwice(void);
void H_BuzzerLong(void);


#endif /* BUZZER_H_ */