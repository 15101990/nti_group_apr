/*
 * Buzzer.c
 *
 * Created: 4/16/2022 3:17:14 PM
 *  Author: yasmine mostafa
 */ 

#include "Buzzer.h"

#define F_CPU  16000000UL
#include <util/delay.h>

void H_BuzzerInit(void)
{
	M_PinMode(Buzzer_Pin,OUTPUT);
}

void H_BuzzerOn(void)
{
	M_PinWrite(Buzzer_Pin,HIGH);
	
}
void BuzzerOff(void)
{
	M_PinWrite(Buzzer_Pin,LOW);
	
}
void H_BuzzerOnce(void)
{
	M_PinWrite(Buzzer_Pin,HIGH);
	_delay_ms(1000);
	M_PinWrite(Buzzer_Pin,LOW);

}
void H_BuzzerTwice(void)
{
	M_PinWrite(Buzzer_Pin,HIGH);
	_delay_ms(50);
	M_PinWrite(Buzzer_Pin,LOW);
	_delay_ms(50);
	M_PinWrite(Buzzer_Pin,HIGH);
	_delay_ms(50);
	M_PinWrite(Buzzer_Pin,LOW);

}

void H_BuzzerLong(void)
{
	M_PinWrite(Buzzer_Pin,HIGH);
	_delay_ms(5000);
	M_PinWrite(Buzzer_Pin,LOW);

}
