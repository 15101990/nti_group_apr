/*
 * SSD.h
 *
 * Created: 4/15/2022 3:05:56 PM
 *  Author: yasmine mostafa
 */ 


#ifndef SSD_H_
#define SSD_H_

#include "SSD_CFG.h"
#include "STD.h"
#include "DIO.h"


#define F_CPU	16000000UL
#include <util/delay.h>

void H_SsdInit(void);
void H_SsdDisplay(uint8);
void H_SsdCountUp(uint8);
void H_SsdCountDown(uint8);
void H_SsdDisplayBLink(uint8);


#define DIRECT_MODE		1
#define DECODER_MODE	2


#endif /* SSD_H_ */