/*
 * SSD_CFG.h
 *
 * Created: 4/15/2022 3:06:07 PM
 *  Author: yasmine mostafa
 */ 


#ifndef SSD_CFG_H_
#define SSD_CFG_H_


#define SSD_A	PA1
#define SSD_B	PA2
#define SSD_C	PA3
#define SSD_D	PA4
#define SSD_E	PA5
#define SSD_F	PA6
#define SSD_G	PA7

#define DECODER_1	PA4
#define DECODER_2	PA5
#define DECODER_3	PA6
#define DECODER_4	PA7


#define SSD_Q1		PB2
#define SSD_Q2		PB1


//SSD_MODE OPTIONS --> [DIRECT_MODE , DECODER_MODE]
#define SSD_MODE	DIRECT_MODE
#endif /* SSD_CFG_H_ */