/*
 * SSD.c
 *
 * Created: 4/15/2022 3:05:45 PM
 *  Author: yasmine mostafa
 */ 

#include "SSD.h"
#include "LED.h"

void H_SsdInit(void)
{
	M_PinMode(SSD_Q1,OUTPUT);
	M_PinMode(SSD_Q2,OUTPUT);
	#if SSD_MODE	==	DIRECT_MODE
	M_PinMode(SSD_A,OUTPUT);
	M_PinMode(SSD_B,OUTPUT);
	M_PinMode(SSD_C,OUTPUT);
	M_PinMode(SSD_D,OUTPUT);
	M_PinMode(SSD_E,OUTPUT);
	M_PinMode(SSD_F,OUTPUT);
	M_PinMode(SSD_G,OUTPUT);
	
	#elif	SSD_MODE	==	DIRECT_MODE
	M_PinMode(DECODER_1,OUTPUT);
	M_PinMode(DECODER_2,OUTPUT);
	M_PinMode(DECODER_3,OUTPUT);
	M_PinMode(DECODER_4,OUTPUT);
		
	#endif

}

void H_SsdDisplayBLink(uint8 Number)
{
	uint8 tens = Number / 10 ;
	uint8 ones = Number % 10;
	
	uint8 i =0;
	for(i=0;i<100;i++)
	{
		#if		SSD_MODE	==	DIRECT_MODE
		M_PinWrite(SSD_Q1,HIGH);
		M_PinWrite(SSD_Q2,LOW);
		
		switch(ones)
		{
			case 0:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,LOW);
			break;
			case 1:
			M_PinWrite(SSD_A,LOW);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,LOW);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,LOW);
			break;
			case 2:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,LOW);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 3:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 4:
			M_PinWrite(SSD_A,LOW);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,LOW);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 5:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,LOW);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 6:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,LOW);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 7:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,LOW);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,LOW);
			break;
			case 8:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 9:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			
			default:
			break;
		}
		_delay_ms(5);
		
		M_PinWrite(SSD_Q1,LOW);
		M_PinWrite(SSD_Q2,HIGH);


		switch(tens)
		{
			case 0:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,LOW);
			break;
			case 1:
			M_PinWrite(SSD_A,LOW);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,LOW);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,LOW);
			break;
			case 2:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,LOW);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 3:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 4:
			M_PinWrite(SSD_A,LOW);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,LOW);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 5:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,LOW);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 6:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,LOW);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 7:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,LOW);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 8:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,HIGH);
			M_PinWrite(SSD_E,HIGH);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			case 9:
			M_PinWrite(SSD_A,HIGH);
			M_PinWrite(SSD_B,HIGH);
			M_PinWrite(SSD_C,HIGH);
			M_PinWrite(SSD_D,LOW);
			M_PinWrite(SSD_E,LOW);
			M_PinWrite(SSD_F,HIGH);
			M_PinWrite(SSD_G,HIGH);
			break;
			
			default:
			break;
		}
		_delay_ms(5);
		M_PinWrite(SSD_Q1,LOW);
		M_PinWrite(SSD_Q2,LOW);

		#elif	SSD_MODE	==	DECODER_MODE

		M_PinWrite(SSD_Q1,LOW);
		M_PinWrite(SSD_Q2,HIGH);
		
		switch(ones)
		{
			case 0:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 1:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 2:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 3:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 4:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 5:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			case 6:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 7:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 8:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,HIGH);
			break;
			
			case 9:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,HIGH);
			break;
			
			default:
			break;

		}
		_delay_ms(5);
		M_PinWrite(SSD_Q1,HIGH);
		M_PinWrite(SSD_Q2,LOW);
		
		switch(tens)
		{
			case 0:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 1:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 2:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 3:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 4:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 5:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			case 6:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 7:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,HIGH);
			M_PinWrite(DECODER_3,HIGH);
			M_PinWrite(DECODER_4,LOW);
			break;
			
			case 8:
			M_PinWrite(DECODER_1,LOW);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,HIGH);
			break;
			
			case 9:
			M_PinWrite(DECODER_1,HIGH);
			M_PinWrite(DECODER_2,LOW);
			M_PinWrite(DECODER_3,LOW);
			M_PinWrite(DECODER_4,HIGH);
			break;
			
			default:
			break;

		}
		
		_delay_ms(5);
		M_PinWrite(SSD_Q1,LOW);
		M_PinWrite(SSD_Q2,LOW);
		
		#endif
	}
}

void H_SsdDisplay(uint8 Number)
{
	uint8 tens = Number / 10 ;
	uint8 ones = Number % 10;
	
	
for(;;)
{
	#if		SSD_MODE	==	DIRECT_MODE
	M_PinWrite(SSD_Q1,HIGH);
	M_PinWrite(SSD_Q2,LOW);
	
	switch(ones)
	{
		case 0:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,HIGH);
		M_PinWrite(SSD_E,HIGH);
		M_PinWrite(SSD_F,HIGH);
		M_PinWrite(SSD_G,LOW);
		break;
		case 1:
		M_PinWrite(SSD_A,LOW);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,LOW);
		M_PinWrite(SSD_E,LOW);
		M_PinWrite(SSD_F,LOW);
		M_PinWrite(SSD_G,LOW);
		break;
		case 2:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,LOW);
		M_PinWrite(SSD_D,HIGH);
		M_PinWrite(SSD_E,HIGH);
		M_PinWrite(SSD_F,LOW);
		M_PinWrite(SSD_G,HIGH);
		break;
		case 3:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,HIGH);
		M_PinWrite(SSD_E,LOW);
		M_PinWrite(SSD_F,LOW);
		M_PinWrite(SSD_G,HIGH);
		break;
		case 4:
		M_PinWrite(SSD_A,LOW);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,LOW);
		M_PinWrite(SSD_E,LOW);
		M_PinWrite(SSD_F,HIGH);
		M_PinWrite(SSD_G,HIGH);
		break;
		case 5:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,LOW);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,HIGH);
		M_PinWrite(SSD_E,LOW);
		M_PinWrite(SSD_F,HIGH);
		M_PinWrite(SSD_G,HIGH);
		break;
		case 6:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,LOW);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,HIGH);
		M_PinWrite(SSD_E,HIGH);
		M_PinWrite(SSD_F,HIGH);
		M_PinWrite(SSD_G,HIGH);
		break;
		case 7:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,LOW);
		M_PinWrite(SSD_E,LOW);
		M_PinWrite(SSD_F,LOW);
		M_PinWrite(SSD_G,LOW);
		break;
		case 8:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,HIGH);
		M_PinWrite(SSD_E,HIGH);
		M_PinWrite(SSD_F,HIGH);
		M_PinWrite(SSD_G,HIGH);
		break;
		case 9:
		M_PinWrite(SSD_A,HIGH);
		M_PinWrite(SSD_B,HIGH);
		M_PinWrite(SSD_C,HIGH);
		M_PinWrite(SSD_D,HIGH);
		M_PinWrite(SSD_E,LOW);
		M_PinWrite(SSD_F,HIGH);
		M_PinWrite(SSD_G,HIGH);
		break;
		
		default:
		break;
	}
_delay_ms(5);
	
M_PinWrite(SSD_Q1,LOW);
M_PinWrite(SSD_Q2,HIGH);


switch(tens)
{
	case 0:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,HIGH);
	M_PinWrite(SSD_E,HIGH);
	M_PinWrite(SSD_F,HIGH);
	M_PinWrite(SSD_G,LOW);
	break;
	case 1:
	M_PinWrite(SSD_A,LOW);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,LOW);
	M_PinWrite(SSD_E,LOW);
	M_PinWrite(SSD_F,LOW);
	M_PinWrite(SSD_G,LOW);
	break;
	case 2:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,LOW);
	M_PinWrite(SSD_D,HIGH);
	M_PinWrite(SSD_E,HIGH);
	M_PinWrite(SSD_F,LOW);
	M_PinWrite(SSD_G,HIGH);
	break;
	case 3:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,HIGH);
	M_PinWrite(SSD_E,LOW);
	M_PinWrite(SSD_F,LOW);
	M_PinWrite(SSD_G,HIGH);
	break;
	case 4:
	M_PinWrite(SSD_A,LOW);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,LOW);
	M_PinWrite(SSD_E,LOW);
	M_PinWrite(SSD_F,HIGH);
	M_PinWrite(SSD_G,HIGH);
	break;
	case 5:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,LOW);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,HIGH);
	M_PinWrite(SSD_E,LOW);
	M_PinWrite(SSD_F,HIGH);
	M_PinWrite(SSD_G,HIGH);
	break;
	case 6:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,LOW);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,HIGH);
	M_PinWrite(SSD_E,HIGH);
	M_PinWrite(SSD_F,HIGH);
	M_PinWrite(SSD_G,HIGH);
	break;
	case 7:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,HIGH);
	M_PinWrite(SSD_E,LOW);
	M_PinWrite(SSD_F,LOW);
	M_PinWrite(SSD_G,HIGH);
	break;
	case 8:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,HIGH);
	M_PinWrite(SSD_E,HIGH);
	M_PinWrite(SSD_F,HIGH);
	M_PinWrite(SSD_G,HIGH);
	break;
	case 9:
	M_PinWrite(SSD_A,HIGH);
	M_PinWrite(SSD_B,HIGH);
	M_PinWrite(SSD_C,HIGH);
	M_PinWrite(SSD_D,LOW);
	M_PinWrite(SSD_E,LOW);
	M_PinWrite(SSD_F,HIGH);
	M_PinWrite(SSD_G,HIGH);
	break;
	
	default:
	break;
}
_delay_ms(5);
M_PinWrite(SSD_Q1,LOW);
M_PinWrite(SSD_Q2,LOW);

#elif	SSD_MODE	==	DECODER_MODE

	M_PinWrite(SSD_Q1,LOW);
	M_PinWrite(SSD_Q2,HIGH);
	
	switch(ones)
	{
		case 0:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 1:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 2:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 3:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 4:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 5:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		case 6:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 7:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 8:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,HIGH);
		break;
		
		case 9:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,HIGH);
		break;
		
		default:
		break;

	}
	_delay_ms(5);
	M_PinWrite(SSD_Q1,HIGH);
	M_PinWrite(SSD_Q2,LOW);
	
	switch(tens)
	{
		case 0:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 1:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 2:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 3:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 4:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 5:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		case 6:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 7:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,HIGH);
		M_PinWrite(DECODER_3,HIGH);
		M_PinWrite(DECODER_4,LOW);
		break;
		
		case 8:
		M_PinWrite(DECODER_1,LOW);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,HIGH);
		break;
		
		case 9:
		M_PinWrite(DECODER_1,HIGH);
		M_PinWrite(DECODER_2,LOW);
		M_PinWrite(DECODER_3,LOW);
		M_PinWrite(DECODER_4,HIGH);
		break;
		
		default:
		break;

	}
	
	_delay_ms(5);
	M_PinWrite(SSD_Q1,LOW);
	M_PinWrite(SSD_Q2,LOW);
	
	#endif
}
}

void H_SsdCountUp(uint8 NUMBER)
{
	
	uint8 i =0 ;
	for(i=0;i<NUMBER;i++)
	{
		H_SsdDisplayBLink(i);
	}
}

void H_SsdCountDown(uint8 NUMBER)
{
	
	uint8 i =0 ;
	for(i=NUMBER;i>=0;i--)
	{
		H_SsdDisplayBLink(i);
	}
}

