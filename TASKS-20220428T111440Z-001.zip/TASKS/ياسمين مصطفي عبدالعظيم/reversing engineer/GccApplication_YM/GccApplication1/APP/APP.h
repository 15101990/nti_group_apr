/*
 * APP.h
 *
 * Created: 4/24/2022 1:10:01 AM
 *  Author: yasmine mostafa
 */ 


#ifndef APP_H_
#define APP_H_
#include "P_Button.h"
#include "LCD.h"
#include "TIMER_0.h"
#include "STD.h"
#include "DIO.h"

void TIMER_0_Exc(void);

void ASKING(void);
void CheckAnswer(uint8);
void Right_Answer(void);
void Wrong_Answer(void);



#endif /* APP_H_ */