/*
 * APP.c
 *
 * Created: 4/24/2022 1:09:47 AM
 *  Author: yasmine mostafa
 */ 

#include "APP.h"

uint8 Global_Question = 0;
uint8 Global_Counter = P_B1;


void ASKING(void)
{ 
	
			H_LcdGoTo(1,0);
			H_LcdWriteCharacter('Q');
			H_LcdWriteCharacter('-');
			if(Global_Question<10)
			{
				H_LcdWriteNumber(0);
				H_LcdWriteNumber(Global_Question);

			}
			else
			{
				H_LcdWriteNumber(Global_Question);
			}
			H_LcdGoTo(1,9);
			H_LcdWriteCharacter('A');
			H_LcdGoTo(1,11);
			H_LcdWriteCharacter('B');
			H_LcdGoTo(1,13);
			H_LcdWriteCharacter('C');
			H_LcdGoTo(1,15);
			H_LcdWriteCharacter('D');

		
		_delay_ms(1000);
	
	
	for(Global_Counter = P_B1 ; Global_Counter <= P_B4 ; Global_Counter++)
	{
		if(H_PushButtonRead(Global_Counter)== PRESSED)
		{
			_delay_ms(50);
			
			if(H_PushButtonRead(Global_Counter)== PRESSED)
			{
				CheckAnswer(Global_Question);
			}
			
		}
	}	
	
}
		


void CheckAnswer(uint8 Local_question)
{
	switch(Local_question)
	{
		case 1 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 2 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 3 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		
		case 4 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 5 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 6 :
		if(H_PushButtonRead(P_B1)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 7 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 8 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 9 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 10 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 11 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 12 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 13 :
		if(H_PushButtonRead(P_B2)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 14 :
		if(H_PushButtonRead(P_B2)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 15 :
		if(H_PushButtonRead(P_B1)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 16 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 17 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 18 :
		if(H_PushButtonRead(P_B1)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
			}
		break;
	
		case 19 :
		if(H_PushButtonRead(P_B2)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}	
	 break;	
		case 20 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 21 :
		if(H_PushButtonRead(P_B4)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 22 :
		if(H_PushButtonRead(P_B2)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 23 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 24 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 25 :
		if(H_PushButtonRead(P_B2)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 26 :
		if(H_PushButtonRead(P_B1)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 27 :
		if(H_PushButtonRead(P_B1)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 28 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 29 :
		if(H_PushButtonRead(P_B1)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		case 30 :
		if(H_PushButtonRead(P_B3)==PRESSED)
		{
			Right_Answer();
		}
		else {
			Wrong_Answer();
		}
		break;
		default:
		break;
		
	}
	
}

void Right_Answer(void)
{
	
	
	if(H_PushButtonRead(P_B1)== PRESSED)
	{	H_LcdGoTo(1,8);
		H_LcdWriteString("[A] B C D");
	}
	
	if(H_PushButtonRead(P_B2)== PRESSED)
	{
	H_LcdGoTo(1,8);
	H_LcdWriteString("A [B] C D");
	}
	if(H_PushButtonRead(P_B3)== PRESSED)
	{
	H_LcdGoTo(1,8);
	H_LcdWriteString("A B [C] D");
	}
	if(H_PushButtonRead(P_B4)== PRESSED)
	{
	H_LcdGoTo(1,8);
	H_LcdWriteString("A B C [D]");
	}
	
	H_LcdClear();
	H_LcdGoTo(1,4);
	H_LcdWriteString("GREAT");
	Global_Question ++ ;
	ASKING();
}


void Wrong_Answer(void)
{
	uint8 Local_minute = 0;
	H_LcdClear();
	H_LcdGoTo(0,4);
	H_LcdWriteString("Loser");
	_delay_ms(1000);
	H_LcdClear();
	H_LcdGoTo(0,1);
	H_LcdWriteString("One Minute penalty");
	Local_minute++;
	ASKING();
}