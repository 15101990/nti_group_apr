/*
 * GccApplication1.c
 *
 * Created: 4/8/2022 12:16:02 AM
 * Author : yasmine mostafa
 */ 

#include "STD.h"
#include "DIO.h"
#include "LED.h"
#include "LED_CFG.h"
#include "P_Button.h"
#include "SSD.h"
#include "LCD.h"
#include "UART.h"
#include "APP.h"
#include "Timer_0.h"
void TIMER_0_Exc(void);

#define  F_CPU	 16000000UL
#include <util/delay.h>

uint8 Global_second = 0;
uint8 Global_minute = 0;
uint8 Global_hour=0;
uint8 Global_Flag=1;
int main(void)
{ 
	
	H_PushButtonInit(P_B1);
	H_PushButtonInit(P_B2);
	H_PushButtonInit(P_B3);
	H_PushButtonInit(P_B4);
	H_LcdInit();
	M_Timer0Init();
	M_Timer_0_SetCallBack(TIMER_0_Exc);
	M_Timer0SetTime(1000);
	M_Timer0Start();
	
	
	if(Global_Flag == 1)
	{
			Global_second++;
			if(Global_second == 60)
			{
				Global_second = 0;
				Global_minute ++ ;
			}
			if(Global_minute == 60)
			{
				Global_minute = 0;
				Global_hour ++;
			}
			Global_Flag = 0;
	}
	

    /* Replace with your application code */
    while (1) 
    { 
		H_LcdGoTo(0,3);
		H_LcdWriteString("let's start");
		H_Lcd_Stop_Watch_Display(Global_second,Global_minute,Global_hour);
		ASKING();
	
   }


void TIMER_0_Exc(void)
	{
	Global_Flag = 1;
	}
}