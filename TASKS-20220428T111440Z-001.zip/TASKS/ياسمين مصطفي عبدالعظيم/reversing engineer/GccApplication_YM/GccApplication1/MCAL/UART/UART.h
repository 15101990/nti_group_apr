/*
 * UART.h
 *
 * Created: 4/22/2022 4:29:54 PM
 *  Author: yasmine mostafa
 */ 


#ifndef UART_H_
#define UART_H_

#include "BIT_MATH.h"
#include "STD.h"
#include "UART_CFG.h"
#include "REG.h"
#include "DIO.h"

void M_UartInit(void);

void M_UartSend(uint8);

uint8 M_UartRec(void);

#define Off		0
#define Even	2
#define Odd		1

#define Asynchronous	1
#define synchronous		2
#endif /* UART_H_ */