/*
 * UART.c
 *
 * Created: 4/22/2022 4:29:42 PM
 *  Author: yasmine mostafa
 */ 

#include "UART.h"

void M_UartInit(void)
{
	uint8 Local_UCSRC_Value = 0b1000000 ; // to select UCSRC as register to use it 
	SET_BIT(DDRD,1); // enable output circuit
	CLEAR_BIT(DDRD,0); //enable input cicuit
	
	#if		CHARACTER_SIZE	==	8
	
	CLEAR_BIT(UCSRB,2);
	SET_BIT(Local_UCSRC_Value,1);
	SET_BIT(Local_UCSRC_Value,2);
	#elif	CHARACTER_SIZE	==	7
	CLEAR_BIT(UCSRB,2);
	CLEAR_BIT(Local_UCSRC_Value,1);
	SET_BIT(Local_UCSRC_Value,2);
	#endif
	// to select Character Size 8 bits
	CLEAR_BIT(UCSRB,2);
	SET_BIT(Local_UCSRC_Value,1);
	SET_BIT(Local_UCSRC_Value,2);
	
	#if UART_MODE	 ==	 Asynchronous 
	// to select UART MODE (Asynchronous )
	CLEAR_BIT(Local_UCSRC_Value,6);
	
	#elif UART_MODE	 ==	 Synchronous
	SET_BIT(Local_UCSRC_Value,6);
	#endif
	
	#if		PARITY_MODE		==	Even
	// to select parity mode 
	SET_BIT(Local_UCSRC_Value,5);
	CLEAR_BIT(Local_UCSRC_Value,4);
	#elif	PARITY_MODE		==	Odd
	// to select parity mode
	SET_BIT(Local_UCSRC_Value,5);
	SET_BIT(Local_UCSRC_Value,4);
	#elif	PARITY_MODE		== Off
	// to select parity mode
	CLEAR_BIT(Local_UCSRC_Value,5);
	CLEAR_BIT(Local_UCSRC_Value,4);
	#endif
	
	#if		STOP_BIT	==		1
	CLEAR_BIT(Local_UCSRC_Value,3);  	// to select one stop bit

	#elif	STOP_BIT	==		2
	SET_BIT(Local_UCSRC_Value,3); // to select 2 stop bit
	#endif
	
	
	#if BAUD_RATE	==	9600
	UBRRL = 103 ;  // after using equation UBRR = ((fosc)/(16 * 9600) ) -1
	#elif BAUD_RATE	==	115200
	UBRRL = 8;
	#endif
	
	UCSRC = Local_UCSRC_Value;  
	
	// enable receiver circuit
	SET_BIT(UCSRB,3);
	//enable transmission circuit
	SET_BIT(UCSRB,4);
	
}
void M_UartSend(uint8 Local_Data)
{
	UDR = Local_Data ; 
	while((GET_BIT(UCSRA,6)== 0)); // polling to check the transmission is done or not 
	
}
uint8  M_UartRec(void)
{
	while((GET_BIT(UCSRA,7)== 0));
	return UDR ;	
}