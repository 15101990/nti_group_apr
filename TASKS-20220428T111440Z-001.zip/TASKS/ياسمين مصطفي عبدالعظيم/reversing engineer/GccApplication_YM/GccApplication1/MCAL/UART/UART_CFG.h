/*
 * UART_CFG.h
 *
 * Created: 4/22/2022 4:30:08 PM
 *  Author: yasmine mostafa
 */ 


#ifndef UART_CFG_H_
#define UART_CFG_H_

// UART_MODE -->[ synchronous - asynchronous ]
#define UART_MODE	Asynchronous 

//PARITY_BIT --> [Odd,Even,off]
#define PARITY_MODE		Even

// STOP_BIT -- >[1 ,2 ]
#define STOP_BIT	1

//select BAUD_RATE -->[9600, ..]
#define BAUD_RATE	9600

// CHARACTER_SIZE Options -->[5,6,7,8,9]
#define CHARACTER_SIZE	8

#endif /* UART_CFG_H_ */