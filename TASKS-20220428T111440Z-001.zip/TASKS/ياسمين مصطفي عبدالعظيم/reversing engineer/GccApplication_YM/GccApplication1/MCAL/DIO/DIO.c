/*
 * DIO.c
 *
 * Created: 4/8/2022 12:54:34 AM
 *  Author: yasmine mostafa
 */ 

#include "STD.h"
#include "REG.h"
#include "BIT_MATH.h"
#include "DIO.h"


void M_PinMode(uint8 ID,uint8 state)
{
	uint8 port = ID / 10;
	uint8 pin = ID % 10;
	
	switch(state)
	{
		case INPUT:
		switch(port)
		{
			case PORT_A:
			CLEAR_BIT(DDRA,pin);
			break;
			
			case PORT_B:
			CLEAR_BIT(DDRB,pin);
			break;
			
			case PORT_C:
			CLEAR_BIT(DDRC,pin);
			break;
			
			case PORT_D:
			CLEAR_BIT(DDRD,pin);
			break;
			
			default:
			break;
		}
		break;
		
		case OUTPUT:
		switch(port)
		{
				case PORT_A:
				SET_BIT(DDRA,pin);
				break;
				
				case PORT_B:
				SET_BIT(DDRB,pin);
				break;
				
				case PORT_C:
				SET_BIT(DDRC,pin);
				break;
				
				case PORT_D:
				SET_BIT(DDRD,pin);
				break;
				
				default:
				break;
		}
		break;
		
		default:
		break;
	}
	
}
void M_PinWrite(uint8 ID ,uint8 state)
{
	uint8 port = ID / 10;
	uint8 pin = ID % 10;
	
	switch(state)
	{
		case LOW:
		switch(port)
		{
			case PORT_A:
			CLEAR_BIT(PORTA,pin);
			break;
			
			case PORT_B:
			CLEAR_BIT(PORTB,pin);
			break;
			
			case PORT_C:
			CLEAR_BIT(PORTC,pin);
			break;
			
			case PORT_D:
			CLEAR_BIT(PORTD,pin);
			break;
			
			default:
			break;
		}
		break;
		
		case HIGH:
		switch(port)
		{
			case PORT_A:
			SET_BIT(PORTA,pin);
			break;
			
			case PORT_B:
			SET_BIT(PORTB,pin);
			break;
			
			case PORT_C:
			SET_BIT(PORTC,pin);
			break;
			
			case PORT_D:
			SET_BIT(PORTD,pin);
			break;
			
			default:
			break;
		}
		break;
		
		default:
		break;
	}
	
}
void M_PinTog(uint8 ID)
{
	
	uint8 port = ID / 10;
	uint8 pin = ID % 10;
	
		switch(port)
		{
			case PORT_A:
			TOG_BIT(PORTA,pin);
			break;
			
			case PORT_B:
			TOG_BIT(PORTB,pin);
			break;
			
			case PORT_C:
			TOG_BIT(PORTC,pin);
			break;
			
			case PORT_D:
			TOG_BIT(PORTD,pin);
			break;
			
			default:
			break;
		}
}
uint8 M_PinRead(uint8 ID)
{
	uint8 port = ID / 10;
	uint8 pin = ID  %  10;
	uint8 reading = 0;
	
	switch(port)
	{
		case PORT_A:
		reading = GET_BIT(PINA,pin);
		break;
		
		case PORT_B:
		reading = GET_BIT(PINB,pin);
		break;
		
		case PORT_C:
		reading = GET_BIT(PINC,pin);
		break;
		
		case PORT_D:
		reading = GET_BIT(PIND,pin);
		break;
		
		default:
		break;
	}
	
	return reading ;
}

void M_PinPullUp(uint8 x,uint8 state)
{
	uint8 port = x / 10;
	uint8 pin  = x % 10;
	switch(state)
	{
		case DISABLE:
		switch(port)
		{
			case PORT_A:
			CLEAR_BIT(PORTA,pin);
			break;
			case PORT_B:
			CLEAR_BIT(PORTB,pin);
			break;
			case PORT_C:
			CLEAR_BIT(PORTC,pin);
			break;
			case PORT_D:
			CLEAR_BIT(PORTD,pin);
			break;
			default:
			break;
		}
		break;
		case ENABLE:
		switch(port)
		{
			case PORT_A:
			SET_BIT(PORTA,pin);
			break;
			case PORT_B:
			SET_BIT(PORTB,pin);
			break;
			case PORT_C:
			SET_BIT(PORTC,pin);
			break;
			case PORT_D:
			SET_BIT(PORTD,pin);
			break;
			default:
			break;
		}
		break;
		default:
		break;
	}
}