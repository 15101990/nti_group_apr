/*
 * DIO.h
 *
 * Created: 4/8/2022 12:54:23 AM
 *  Author: yasmine mostafa
 */ 


#ifndef DIO_H_
#define DIO_H_

#include "STD.h"

void M_PinMode(uint8,uint8);
void M_PinWrite(uint8,uint8);
void M_PinTog(uint8);
uint8 M_PinRead(uint8);
void M_PinPullUp(uint8,uint8);


#define		OUTPUT			1
#define		INPUT			0
#define		LOW				0
#define		HIGH			1
#define		DISABLE			0
#define		ENABLE		    1 


#define		PA0			10
#define		PA1			11
#define		PA2			12
#define		PA3			13
#define		PA4			14
#define		PA5			15
#define		PA6			16
#define		PA7			17

#define		PB0			20
#define		PB1			21
#define		PB2			22
#define		PB3			23
#define		PB4			24
#define		PB5			25
#define		PB6			26
#define		PB7			27

#define		PC0			30
#define		PC1			31
#define		PC2			32
#define		PC3			33
#define		PC4			34
#define		PC5			35
#define		PC6			36
#define		PC7			37

#define		PD0			40
#define		PD1			41
#define		PD2			42
#define		PD3			43
#define		PD4			44
#define		PD5			45
#define		PD6			46
#define		PD7			47


#define		PORT_A		1
#define		PORT_B		2
#define		PORT_C		3
#define		PORT_D		4


#endif /* DIO_H_ */