/*
 * EXT_INT_CFG.h
 *
 * Created: 4/14/2022 1:22:11 AM
 *  Author: yasmine mostafa
 */ 


#ifndef EXT_INT_CFG_H_
#define EXT_INT_CFG_H_





#endif /* EXT_INT_CFG_H_ */