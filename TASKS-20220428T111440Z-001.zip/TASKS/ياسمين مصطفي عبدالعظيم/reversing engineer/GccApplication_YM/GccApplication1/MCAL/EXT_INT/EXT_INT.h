/*
 * EXT_INT.h
 *
 * Created: 4/14/2022 1:21:52 AM
 *  Author: yasmine mostafa
 */ 


#ifndef EXT_INT_H_
#define EXT_INT_H_

#include "STD.h"

void M_ExtIntInit(void);





#endif /* EXT_INT_H_ */