/*
 * Timer_0.c
 *
 * Created: 4/27/2022 1:14:23 AM
 *  Author: yasmine mostafa
 */ 

#include "Timer_0.h"
#include "Timer_0_CFG.h"

#include "STD.h"
#include "BIT_MATH.h"

#include <avr/interrupt.h>

void (*call_back)(void);

uint32 global_no_of_ov =0 ;
uint8 global_rem_ticks = 0;
uint32 global_no_of_cm =0 ;


void M_Timer0Init(void)
{
	// to select normal mode
	#if		TIMER_0_MODE	==	NORMAL_MODE
	CLEAR_BIT(TCCR0,3);
	CLEAR_BIT(TCCR0,6);
	
	//to enable timer ov interrrupt
	SET_BIT(TIMSK,0);
	
	#elif	TIMER_0_MODE	==	CTC_MODE
	SET_BIT(TCCR0,3);
	CLEAR_BIT(TCCR0,6);
	//to enable compare match ov interrrupt
	SET_BIT(TIMSK,1);
	#endif
	
	// to enable global interrupt
	SET_BIT(SREG,7);
	
	
}


void M_Timer0SetTime(uint32 local_desired_time) // to calculate no.overflow
{
	uint32 local_tick_time = PRESCALER_D_F / CRYSTAL_FREQ  ; //  64 in micro sec
	uint32 local_total_ticks = (local_desired_time * 1000 ) / local_tick_time ; // *1000 for conversion from milli to micro
	#if		TIMER_0_MODE	==	NOTMAL_MODE
	
	global_no_of_ov = local_total_ticks / 256 ;
	global_rem_ticks =local_total_ticks % 256;
	
	if(global_rem_ticks != 0)
	{
		TCNT0		= 256 - global_rem_ticks;
		global_no_of_ov++ ;
		
	}
	
	#elif	TIMER_0_MODE		==	CTC_MODE
	uint8 local_division_number=255;
	while(local_total_ticks % local_division_number)
	{
		
		local_division_number--;
	}
	global_no_of_cm = local_total_ticks / local_division_number;
	OCR0  = local_division_number - 1;
	
	#endif
}
void M_Timer0Start(void)
{
	#if		PRESCALER_D_F	== 1024
	// to select prescaler 1024
	SET_BIT(TCCR0,0);
	CLEAR_BIT(TCCR0,1);
	SET_BIT(TCCR0,2);
	
	#elif  PRESCALER_D_F	== 256
	CLEAR_BIT(TCCR0,0);
	CLEAR_BIT(TCCR0,1);
	SET_BIT(TCCR0,2);
	
	#endif
}
void M_Timer0Stop(void)
{
	CLEAR_BIT(TCCR0,0);
	CLEAR_BIT(TCCR0,1);
	CLEAR_BIT(TCCR0,2);
	
	
}
void M_Timer_0_SetCallBack( void (*ptr)(void))
{
	call_back = ptr;
	
}

#if		TIMER_0_MODE	==		NORMAL_MODE
ISR(TIMER0_OVF_vect)
{
	static uint32 local_counter=0;
	local_counter++;
	if(local_counter == global_no_of_ov) //no_of_ov = 62 after 9ticks
	{    call_back();
		local_counter=0;
		TCNT0  = 256 - global_rem_ticks;
	}
}
#elif		TIMER_0_MODE	==		CTC_MODE
ISR(TIMER0_COMP_vect)
{
	static uint32 local_counter=0;
	local_counter++;
	if(local_counter == global_no_of_cm )
	{    call_back();
		local_counter=0;

	}
}

#endif

void M_PWM0Init(void)
{  // to enable output circuit
	SET_BIT(DDRB,3);
	#if PWM0MODE	==	FAST_PWM
	
	//to select Fast PWM
	SET_BIT(TCCR0,3);
	SET_BIT(TCCR0,6);
	
	//to select non inverted mode
	CLEAR_BIT(TCCR0,4);
	SET_BIT(TCCR0,5);
	
	#elif PWM0MODE	==	PHASE_CORRECT_PWM
	// to select phase correct pwm
	CLEAR_BIT(TCCR0,3);
	SET_BIT(TCCR0,6);
	
	// to select non inverted mode
	CLEAR_BIT(TCCR0,4);
	SET_BIT(TCCR0,5);
	
	#endif
}


void M_PWM0SetDutyCycle(uint32 local_dutyCycle)  // to calculate time
{
	#if  PWM0MODE	== FAST_PWM
	OCR0 = ((local_dutyCycle * 256 ) / 100) -1 ;
	#elif	PWM0MODE	==	PHASE_CORRECT_PWM
	OCR0 = ((local_dutyCycle * 255 ) / 100) ;
	#endif
	
}
void M_PWM0Start(void) // to start time
{
	M_Timer0Start();  // the same steps in this function
}
void M_PWM0Stop(void)
{
	M_Timer0Stop();
}