/*
 * Timer_0_CFG.h
 *
 * Created: 4/27/2022 1:14:47 AM
 *  Author: yasmine mostafa
 */ 


#ifndef TIMER_0_CFG_H_
#define TIMER_0_CFG_H_



//TIMER_0_MODE options --> []
#define TIMER_0_MODE	CTC_MODE

//select CRYSTAL_FREQ options --> []
#define CRYSTAL_FREQ	16

//select PRESCALER_D_F options--> []

#define PRESCALER_D_F	1024

// select PWM0MODE options -->[FAST_PWM,PHASE_CORRECT_PWM]
#define PWM0MODE	PHASE_CORRECT_PWM




#endif /* TIMER_0_CFG_H_ */