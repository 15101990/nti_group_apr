/*
 * Timer_0.h
 *
 * Created: 4/27/2022 1:14:35 AM
 *  Author: yasmine mostafa
 */ 


#ifndef TIMER_0_H_
#define TIMER_0_H_



#include "STD.h"
#include "REG.h"

void M_Timer0Init(void);
void M_Timer0SetTime(uint32); // to calculate time
void M_Timer0Start(void); // to start time
void M_Timer0Stop(void);
void M_Timer_0_SetCallBack( void (*ptr)(void));

void M_PWM0Init(void);
void M_PWM0SetDutyCycle(uint32); // to calculate time
void M_PWM0Start(void); // to start time
void M_PWM0Stop(void);

#define NORMAL_MODE		1
#define CTC_MODE		2

#define FAST_PWM	3
#define PHASE_CORRECT_PWM	4

#endif /* TIMER_0_H_ */