/*
 * REG.h
 *
 * Created: 4/8/2022 1:22:07 AM
 *  Author: yasmine mostafa
 */ 


#ifndef REG_H_
#define REG_H_



#include "STD.h"

#define PORTA 	(*((volatile uint8*)0x3B))
#define DDRA 	(*((volatile uint8*)0x3A))
#define PINA 	(*((volatile uint8*)0x39))

#define PORTB 	(*((volatile uint8*)0x38))
#define DDRB 	(*((volatile uint8*)0x37))
#define PINB 	(*((volatile uint8*)0x36))

#define PORTC 	(*((volatile uint8*)0x35))
#define DDRC 	(*((volatile uint8*)0x34))
#define PINC 	(*((volatile uint8*)0x33))

#define PORTD 	(*((volatile uint8*)0x32))
#define DDRD 	(*((volatile uint8*)0x31))
#define PIND 	(*((volatile uint8*)0x30))
/********************************_EXT_INT_REGISTERS_*************************************/

#define MCUCR     (*((volatile uint8*)0x55))
#define SREG      (*((volatile uint8*)0x5F))
#define GICR      (*((volatile uint8*)0x5B))

/********************************_TIMER0_REGISTERS_*****************************************/

#define TIMSK     (*((volatile uint8*)0x59))
#define TCCR0     (*((volatile uint8*)0x53))
#define TCNT0     (*((volatile uint8*)0x52))
#define OCR0      (*((volatile uint8*)0x5C))


/**************UART_REGISTER*************/
#define UDR 	(*((volatile uint8*)0x2C))
#define UCSRA	(*((volatile uint8*)0x2B))
#define UCSRB 	(*((volatile uint8*)0x2A))
#define UBRRL	(*((volatile uint8*)0x29))
#define UCSRC	(*((volatile uint8*)0x40))

#endif /* REG_H_ */