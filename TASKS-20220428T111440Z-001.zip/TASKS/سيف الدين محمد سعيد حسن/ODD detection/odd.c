#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include <stdio.h>


u32 OddCount(u32);

void main (void)
{
	u32 input = 0;
	printf("please enter the number:");
	scanf("%d",&input);
	printf("sum = %d\n",OddCount(input));
}
u32 OddCount(u32 number)
{
	u32 sum = 0;
	while(number > 0)
	{
		if(GET_BIT(number,0))
		{
			sum = sum + number;
		}
		number--;
	}
	return sum;
}