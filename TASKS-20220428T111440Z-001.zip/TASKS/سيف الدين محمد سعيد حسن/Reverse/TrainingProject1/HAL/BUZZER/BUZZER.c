/*
 * BUZZER.c
 *
 * Created: 4/6/2022 10:56:43 AM
 *  Author: Saif Mohamed
 */ 


#include "BUZZER.h"
#include "DIO.h"

# define F_CPU 16000000UL
#include <util/delay.h>

void H_BuzzerInit(void)
{
	M_PinMode(BUZZER_PIN,OUTPUT);
}

void H_BuzzerShortBeeb(void)
{
	
	M_PinWrite(BUZZER_PIN,HIGH);
	_delay_ms(100);
	M_PinWrite(BUZZER_PIN,LOW);
	_delay_ms(80);
}

void H_BuzzerDoubleShortBeeb(void)
{
	u8 j = 0;
	for (j;j<2;j++)
	{
		M_PinWrite(BUZZER_PIN,HIGH);
		_delay_ms(100);
		M_PinWrite(BUZZER_PIN,LOW);
		_delay_ms(80);
	}
	
}

void H_BuzzerLongBeeb(void)
{
	M_PinWrite(BUZZER_PIN,HIGH);
	_delay_ms(300);
	M_PinWrite(BUZZER_PIN,LOW);
	_delay_ms(80);
}

void H_BuzzerTribleShortBeeb(void)
{
	u8 j = 0;
	for (j;j<3;j++)
	{
		M_PinWrite(BUZZER_PIN,HIGH);
		_delay_ms(100);
		M_PinWrite(BUZZER_PIN,LOW);
		_delay_ms(80);
	}
	
	
}