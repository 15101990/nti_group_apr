/*
 * STD.h
 *
 * Created: 4/6/2022 12:32:09 AM
 *  Author: Saif Mohamed
 */ 


#ifndef STD_H_
#define STD_H_

#include <stdio.h>

 typedef unsigned  char       u8;
 typedef signed    char       s8;
 typedef unsigned short int   u16;
 typedef signed   short int   s16;
 typedef unsigned long  int   u32;
 typedef signed   long  int   s32;
 typedef float                f32;
 typedef double               f64;

#endif /* STD_H_ */