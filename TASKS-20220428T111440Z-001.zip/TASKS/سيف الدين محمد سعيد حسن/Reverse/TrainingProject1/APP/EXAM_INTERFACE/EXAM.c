/*
 * EXAM.c
 *
 * Created: 4/21/2022 1:07:35 AM
 *  Author: Saif Mohamed
 */ 
#include "STD.h"

#include "EXAM.h"
#include "LCD.h"
#include "TIMER_0.h"
#include "PUSH_BUTTON.h"
#include "PUSH_BUTTON_CFG.h"
#include "BUZZER.h"

# define F_CPU 16000000UL
#include <util/delay.h>

u8 u8_global_seconds	= 0;
u8 u8_global_minutes	= 0;
u8 u8_global_hours		= 0;
u8 u8_global_arr_answer[30] = {'A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A'};
	
void A_ExamInit(void)
{
	H_PushButtonInit(PB_1);
	H_PushButtonInit(PB_2);
	H_PushButtonInit(PB_3);
	H_PushButtonInit(PB_4);
	H_LcdInit();
	H_BuzzerInit();
	M_Timer0Init();
	M_Timer0SetCallBack(A_TIMER0_EXC);
	M_Timer0SetTime(1000);
}


void A_ExamStart(void)
{
	u8 u8_local_counter			 = 0;
	u8 u8_local_choice			 = 5;
	u8 u8_local_answer [5]   = {'A','B','C','D','N'};
		
	H_BuzzerLongBeeb();
	M_Timer0Start();
	
	while(u8_local_counter < 30)
	{
		H_LcdGoTo(0,4);
		if (u8_global_hours < 10)
		{
			H_LcdWriteNumber(0);
			H_LcdWriteNumber(u8_global_hours);
		}
		else
		{
			H_LcdWriteNumber(u8_global_hours);
		}
		H_LcdWriteCharacter(':');
		if (u8_global_minutes < 10)
		{
			H_LcdWriteNumber(0);
			H_LcdWriteNumber(u8_global_minutes);
		}
		else
		{
			H_LcdWriteNumber(u8_global_minutes);
		}
		H_LcdWriteCharacter(':');
		if (u8_global_seconds < 10)
		{
			H_LcdWriteNumber(0);
			H_LcdWriteNumber(u8_global_seconds);
		}
		else
		{
			H_LcdWriteNumber(u8_global_seconds);
		}
		H_LcdGoTo(1,0);
		H_LcdWriteCharacter('Q');
		H_LcdWriteNumber(u8_local_counter+1);
		H_LcdWriteCharacter(':');
		
		H_LcdGoTo(1,8);
		H_LcdWriteString("A B C D");
		u8_local_choice = u8_local_answer[A_GetAnswer()];
		
		if (u8_local_choice == 'N')
		{
			
		}
		else
		{
			if (u8_local_choice == u8_global_arr_answer[u8_local_counter] )
			{
				H_BuzzerShortBeeb();
				H_LcdClear();
				H_LcdGoTo(0,3);
				H_LcdWriteString("->Great<-");
				_delay_ms(500);
				u8_local_counter++;
			}
			else
			{
				H_BuzzerDoubleShortBeeb();
				H_LcdClear();
				H_LcdGoTo(0,3);
				H_LcdWriteString("Wrong!!");
				_delay_ms(500);
				H_LcdClear();
				H_LcdGoTo(0,3);
				H_LcdWriteString("->Loser<-");
				_delay_ms(500);
				H_LcdClear();
				H_LcdGoTo(0,3);
				H_LcdWriteString("One Minute");
				H_LcdGoTo(1,3);
				H_LcdWriteString("Penalty!!!");
				_delay_ms(500);
				H_LcdClear();
				u8_global_minutes++;
			}
		}
		u8_local_choice			 = 5;
	}
	H_BuzzerLongBeeb();
}

u8 A_GetAnswer(void)
{
	u8 u8_local_PB_count		 = 0;
	u8 u8_local_returnValue = 4;
	for (u8_local_PB_count = PB_1 ; u8_local_PB_count <= PB_4 ; u8_local_PB_count++)
	{
		u8 u8_local_read = H_PushButtonRead(u8_local_PB_count);
		if (u8_local_read == PRESSED)
		{
			_delay_ms(50);
			u8_local_read = H_PushButtonRead(u8_local_PB_count);
			if (u8_local_read == PRESSED)
			{
				while ( H_PushButtonRead(u8_local_PB_count) == PRESSED);
				switch(u8_local_PB_count)
				{
					case 1:
					H_LcdGoTo(1,8);
					H_LcdWriteString("[A]B C D");
					_delay_ms(30);
					break;
					case 2:
					H_LcdGoTo(1,8);
					H_LcdWriteString("A[B]C D");
					_delay_ms(30);
					break;
					case 3:
					H_LcdGoTo(1,8);
					H_LcdWriteString("A B[C]D");
					_delay_ms(30);
					case 4:
					H_LcdGoTo(1,8);
					H_LcdWriteString("A B C[D]");
					_delay_ms(30);
					break;
					default:
					break;
				}
				u8_local_returnValue = (u8_local_PB_count-1);
			}
		}
	}
	return u8_local_returnValue;
}

void A_TIMER0_EXC(void)
{
	if (u8_global_seconds < 60)
	{
		u8_global_seconds++;
	}
	else
	{
		u8_global_seconds = 0;
		if (u8_global_minutes< 60)
		{
			u8_global_minutes++;
		}
		else
		{
			u8_global_minutes = 0;
			u8_global_hours++;
		}
	}
}