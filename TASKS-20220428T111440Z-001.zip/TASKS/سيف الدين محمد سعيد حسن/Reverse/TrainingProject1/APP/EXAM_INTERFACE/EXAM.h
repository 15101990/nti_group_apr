/*
 * EXAM.h
 *
 * Created: 4/21/2022 1:07:48 AM
 *  Author: Saif Mohamed
 */ 


#ifndef EXAM_H_
#define EXAM_H_

#include "STD.h"

void A_ExamInit(void);

void A_ExamStart(void);

u8 A_GetAnswer(void);

void A_TIMER0_EXC(void);

#endif /* EXAM_H_ */