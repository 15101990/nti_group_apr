/*
 * ADC.c
 *
 * Created: 4/13/2022 2:20:14 AM
 *  Author: Saif Mohamed
 */ 
#include "STD.h"
#include "BIT_MATH.h"
#include "REG.h"
#include "ADC_CFG.h"
#include "ADC.h"


void M_AdcInit(void)
{
	//to set the reference volt
	#if   V_REF	==	AVCC
	SET_BIT(ADMUX,6);
	CLR_BIT(ADMUX,7);
	#elif V_REF	==	AREF_PIN
	CLR_BIT(ADMUX,6);
	CLR_BIT(ADMUX,7);
	#elif V_REF	==	_2_VOLT	
	SET_BIT(ADMUX,6);
	SET_BIT(ADMUX,6);
	#endif
	
	//to adjust the resolution register 10 bits from right or left
	#if RESULT_ADJUST == RIGHT
	CLR_BIT(ADMUX,5);
	#elif RESULT_ADJUST == LEFT
	SET_BIT(ADMUX,5);
	#endif
	
	//to set the pre=scaler division factor
	#if PRESCALER_D_F == _64
	SET_BIT(ADCSRA,0);
	SET_BIT(ADCSRA,1);
	SET_BIT(ADCSRA,1);
	#elif PRESCALER_D_F == _128
	SET_BIT(ADCSRA,0);
	SET_BIT(ADCSRA,1);
	SET_BIT(ADCSRA,2);
	#endif
	
	//to enable or disable auto 
	#if	  AUTOTRIGGER == ON
	SET_BIT(ADCSRA,5);
	#elif AUTOTRIGGER == OFF
	CLR_BIT(ADCSRA,5);
	#endif

	//to enable the ADC
	SET_BIT(ADCSRA,7);
	
}

u16 M_AdcRead(void)
{
	//to start the conversion
	SET_BIT(ADCSRA,6);
	while ( (GET_BIT(ADCSRA,4)) == 0 );
	return ADC_VALUE;
	
}