/*
 * WATCHDOG.h
 *
 * Created: 4/19/2022 10:38:05 AM
 *  Author: Saif Mohamed
 */ 


#ifndef WATCHDOG_H_
#define WATCHDOG_H_
#include "REG.h"

#define WDT_PRESCALER 1024

void M_WatchDogTimerInit(void);
void M_WatchDogTimerReset(void);




#endif /* WATCHDOG_H_ */