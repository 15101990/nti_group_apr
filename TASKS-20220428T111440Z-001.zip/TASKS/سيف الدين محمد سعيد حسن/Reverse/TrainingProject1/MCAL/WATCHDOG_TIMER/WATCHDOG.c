/*
 * WATCHDOG.c
 *
 * Created: 4/19/2022 10:37:31 AM
 *  Author: Saif Mohamed
 */ 
#include "WATCHDOG.h"
#include "BIT_MATH.h"
#include "REG.h"
# define F_CPU 16000000UL
#include <util/delay.h>

void M_WatchDogTimerInit(void)
{
	
	#if WDT_PRESCALER == 16
	CLR_BIT(WDTCR,0);
	CLR_BIT(WDTCR,1);
	CLR_BIT(WDTCR,2);
	#elif WDT_PRESCALER == 32
	SET_BIT(WDTCR,0);
	CLR_BIT(WDTCR,1);
	CLR_BIT(WDTCR,2);
	#elif WDT_PRESCALER == 64
	CLR_BIT(WDTCR,0);
	SET_BIT(WDTCR,1);
	CLR_BIT(WDTCR,2);
	#elif WDT_PRESCALER == 128
	SET_BIT(WDTCR,0);
	SET_BIT(WDTCR,1);
	CLR_BIT(WDTCR,2);
	#elif WDT_PRESCALER == 256
	CLR_BIT(WDTCR,0);
	CLR_BIT(WDTCR,1);
	SET_BIT(WDTCR,2);
	#elif WDT_PRESCALER == 512
	SET_BIT(WDTCR,0);
	CLR_BIT(WDTCR,1);
	SET_BIT(WDTCR,2);
	#elif WDT_PRESCALER == 1024
	CLR_BIT(WDTCR,0);
	SET_BIT(WDTCR,1);
	SET_BIT(WDTCR,2);
	#elif WDT_PRESCALER == 2048
	SET_BIT(WDTCR,0);
	SET_BIT(WDTCR,1);
	SET_BIT(WDTCR,2);
	#endif
	//enable watchdog timer
	SET_BIT(WDTCR,3);
	
}
void M_WatchDogTimerReset(void)
{
	asm("WDR");
}
