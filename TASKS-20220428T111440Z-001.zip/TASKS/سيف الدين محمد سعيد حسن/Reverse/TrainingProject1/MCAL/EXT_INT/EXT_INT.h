/*
 * EXT_INT.h
 *
 * Created: 4/11/2022 10:07:50 AM
 *  Author: Saif Mohamed
 */ 


#ifndef EXT_INT_H_
#define EXT_INT_H_

void M_ExtInt0Init(void);
void M_SetCallBack(void (*)(void));

#define FALLING_EDGE		1
#define RISING_EDGE			2
#define LOW_LEVEL			3
#define ANY_LOGICAL_CHANGE	4



#endif /* EXT_INT_H_ */