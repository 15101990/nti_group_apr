/*
 * EXT_INT_CFG.h
 *
 * Created: 4/11/2022 10:08:07 AM
 *  Author: Saif Mohamed
 */ 


#ifndef EXT_INT_CFG_H_
#define EXT_INT_CFG_H_

//SENSE_CONTROL options -> (FALLING_EDGE, RISING_EDGE, LOW_LEVEL, ANY_LOGICAL_CHANGE)
#define   SENSE_CONTROL  FALLING_EDGE 



#endif /* EXT_INT_CFG_H_ */