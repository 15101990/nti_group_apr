/*
 * EXT_INT.c
 *
 * Created: 4/11/2022 10:07:36 AM
 *  Author: Saif Mohamed
 */ 
#include "EXT_INT.h"
#include "REG.h"
#include "BIT_MATH.h"
#include <avr/interrupt.h>

void (*Call_Back)(void) = NULL;


void M_ExtInt0Init(void)
{	
	#if   SENSE_CONTROL == FALLING_EDGE
		//to select falling edge (sense control) for INTERRUPT0
		CLR_BIT(MCUCR,0);
		SET_BIT(MCUCR,1);
		
	#elif SENSE_CONTROL == RISING_EDGE
		//to select falling edge (sense control) for INTERRUPT0
		SET_BIT(MCUCR,0);
		SET_BIT(MCUCR,1);
		
	#elif SENSE_CONTROL == LOW_LEVEL
		//to select falling edge (sense control) for INTERRUPT0
		CLR_BIT(MCUCR,0);
		CLR_BIT(MCUCR,1);
		
	#elif SENSE_CONTROL == ANY_LOGICAL_CHANGE
		//to select falling edge (sense control) for INTERRUPT0
		SET_BIT(MCUCR,0);
		CLR_BIT(MCUCR,1);
	#endif
	//enable global interrupt
	SET_BIT(SREG,7);
	//enable extint0
	SET_BIT(GICR,6);
}
void M_SetCallBack(void (*ptr)(void))
{
	Call_Back = ptr;
}
ISR(INT0_vect)
{
	Call_Back();
}