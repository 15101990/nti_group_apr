/*
 * TIMER_0.c
 *
 * Created: 4/13/2022 10:14:24 AM
 *  Author: Saif Mohamed
 */ 




#include "TIMER_0.h"
#include "TIMER_0_CFG.h"
#include "REG.h"
#include "STD.h"
#include "BIT_MATH.h"
#include <avr/interrupt.h>


u32 u32_global_no_of_overflow = 0;
u8  u8_global_remainder_ticks = 0;
u32 u32_global_no_of_cm		  = 0;
void (*call_back)(void) = NULL;

void M_Timer0Init(void)
{
	#if		TIMER_0_MODE	==		NORMAL_MODE
	CLR_BIT(TCCR0,3);
	CLR_BIT(TCCR0,6);
	//To enable timer0 overflow interrupt
	SET_BIT(TIMSK,0);
	
	#elif	TIMER_0_MODE	==		CTC_MODE
	SET_BIT(TCCR0,3);
	CLR_BIT(TCCR0,6);
	// to enable timer0 cm int
	SET_BIT(TIMSK,1);
	
	#endif
	
	//to enable global interrupt
	SET_BIT(SREG,7);
}
void M_Timer0SetTime(u32 u32_local_desired_time)
{
	u32 u32_local_tick_time			= PRESCALER_D_F/CRYSTAL_FREQ; //Micro Second
	u32 u32_local_total_ticks		= (u32_local_desired_time * 1000) / u32_local_tick_time;
	
	#if		TIMER_0_MODE	==		NORMAL_MODE
	u32_global_no_of_overflow		= u32_local_total_ticks / 256;
	u8_global_remainder_ticks		= u32_local_total_ticks % 256;
	if (u8_global_remainder_ticks != 0)
	{
		TCNT0							= 256 - u8_global_remainder_ticks;
		u32_global_no_of_overflow++;
	}
	
	#elif	TIMER_0_MODE	==		CTC_MODE
	u8 u8_local_division_number = 255;
	while(u32_local_total_ticks % u8_local_division_number)
	{
		u8_local_division_number--;
	}
	u32_global_no_of_cm   =  u32_local_total_ticks / u8_local_division_number;
	OCR0                  = u8_local_division_number - 1;
	
	#endif
}
void M_Timer0Start(void)
{
	#if		PRESCALER_D_F	 ==		 1024
	SET_BIT(TCCR0,0);
	CLR_BIT(TCCR0,1);
	SET_BIT(TCCR0,2);
	
	#elif	PRESCALER_D_F	 ==		 256
	CLR_BIT(TCCR0,0);
	CLR_BIT(TCCR0,1);
	SET_BIT(TCCR0,2);
	#endif
}
void M_Timer0Stop(void)
{
	//To stop the timer
	CLR_BIT(TCCR0,0);
	CLR_BIT(TCCR0,1);
	CLR_BIT(TCCR0,2);
}

void M_Timer0SetCallBack(void (*ptr)(void))
{
	call_back = ptr;
}

#if TIMER_0_MODE        ==    NORMAL_MODE
ISR(TIMER0_OVF_vect)
{
	static u32 u32_static_local_counter = 0;
	u32_static_local_counter++;
	if (u32_static_local_counter == u32_global_no_of_overflow)
	{
		call_back();
		u32_static_local_counter = 0;
		TCNT0							= 256 - u8_global_remainder_ticks;
	}
}

#elif TIMER_0_MODE        ==    CTC_MODE
ISR(TIMER0_COMP_vect)
{
	static u32 u32_static_local_counter = 0;
	u32_static_local_counter++;
	if(u32_static_local_counter == u32_global_no_of_cm)
	{
		call_back();
		u32_static_local_counter = 0;
	}
}
#endif

void M_Pwm0Init(void)
{
	// to enable output circuit
	SET_BIT(DDRB,3);
	// to select fast pwm mode
	SET_BIT(TCCR0,3);
	SET_BIT(TCCR0,6);
	// to select non inverted mode
	CLR_BIT(TCCR0,4);
	SET_BIT(TCCR0,5);
}
void M_Pwm0SetDutyCycle(u8 u8_local_dutyCycle)
{
	OCR0 = ((u8_local_dutyCycle * 256 ) / 100 ) - 1;
}
void M_Pwm0Start(void)
{
	M_Timer0Start();
}
void M_Pwm0Stop(void)
{
	M_Timer0Stop();
}
