/*
 * TIMER_0.h
 *
 * Created: 4/13/2022 10:13:44 AM
 *  Author: Saif Mohamed
 */ 


#ifndef TIMER_0_H_
#define TIMER_0_H_

#include "STD.h"

#define	NORMAL_MODE				0
#define	CTC_MODE	   			1
#define FAST_PWM				2
#define PHASE_CORRECT_PWM		3

void M_Timer0Init(void);
void M_Timer0SetTime(u32);
void M_Timer0Start(void);
void M_Timer0SetCallBack(void (*)(void));

void M_Pwm0Init(void);
void M_Pwm0SetDutyCycle(u8);
void M_Pwm0Start(void);
void M_Pwm0Stop(void);


#endif /* TIMER_0_H_ */