/*
 * TIMER_0_CFG.h
 *
 * Created: 4/13/2022 10:14:10 AM
 *  Author: Saif Mohamed
 */ 


#ifndef TIMER_0_CFG_H_
#define TIMER_0_CFG_H_

//choose timer0 mode [NORMAL_MODE , CTC_MODE]
#define TIMER_0_MODE  NORMAL_MODE
//choose crystal oscillator freq in MegaHertz
#define CRYSTAL_FREQ  16
//choose pre-scaler division factor [256 , 1024]
#define PRESCALER_D_F 1024
// PWM0MODE options --> [ PHASE_CORRECT_PWM , FAST_PWM ]
#define PWM0MODE          PHASE_CORRECT_PWM
#endif /* TIMER_0_CFG_H_ */