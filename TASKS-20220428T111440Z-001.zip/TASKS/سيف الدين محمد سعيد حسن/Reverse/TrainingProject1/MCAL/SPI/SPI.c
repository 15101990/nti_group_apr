/*
 * SPI.c
 *
 * Created: 4/21/2022 10:27:40 AM
 *  Author: Saif Mohamed
 */ 

#include "SPI.h"
#include "SPI_CFG.h"
#include "BIT_MATH.h"
#include "DIO.h"
#include "REG.h"

void M_SpiInit(void)
{	
	#if SPI_MODE		==		 MASTER
	SET_BIT(SPCR,4);
	M_PinMode(MOSI,OUTPUT);
	M_PinMode(MISO,INPUT);
	M_PinMode(SS,OUTPUT);
	M_PinMode(SCK,OUTPUT);
	//to select division factor for freq is 128 , SPI freq = 125 KHz
	SET_BIT(SPCR,0);
	SET_BIT(SPCR,1);
	#elif SPI_MODE		==		SLAVE
	CLR_BIT(SPCR,4);
	M_PinMode(MOSI,INPUT);
	M_PinMode(MISO,OUTPUT);
	M_PinMode(SS,INPUT);
	M_PinMode(SCK,INPUT);
	#endif
	
	//to select send from LSB
	SET_BIT(SPCR,5);
	
	//to enable SPI circuit
	SET_BIT(SPCR,6);
}
u8 M_SpiTransive(u8 u8_local_data)
{
	SPDR = u8_local_data;
	while (GET_BIT(SPSR,7) == 0);
	return SPDR;
}