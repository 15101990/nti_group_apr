/*
 * STEPPER_MOTOR.c
 *
 * Created: 4/19/2022 9:44:04 AM
 *  Author: Saif Mohamed
 */ 

#include "DIO.h"
#include "BIT_MATH.h"
#include "STD.h"
#include "STEPPER_MOTOR.h"
#include "STEPPER_MOTOR_CFG.h"
# define F_CPU 16000000UL
#include <util/delay.h>

void H_StepperInit(void)
{
	M_PinMode(IN_1,OUTPUT);
	M_PinMode(IN_2,OUTPUT);
	M_PinMode(IN_3,OUTPUT);
	M_PinMode(IN_4,OUTPUT);
}
void H_StepperRotate(u32 u32_local_angel)
{	
	u32 u32_local_counter = 0;
	for (u32_local_counter; u32_local_counter < u32_local_angel;u32_local_counter++)
	{
		M_PinWrite(IN_1,HIGH);
		M_PinWrite(IN_2,LOW);
		M_PinWrite(IN_3,LOW);
		M_PinWrite(IN_4,LOW);
		_delay_ms(10);
		
		M_PinWrite(IN_1,LOW);
		M_PinWrite(IN_2,HIGH);
		M_PinWrite(IN_3,LOW);
		M_PinWrite(IN_4,LOW);
		_delay_ms(10);
		
		M_PinWrite(IN_1,LOW);
		M_PinWrite(IN_2,LOW);
		M_PinWrite(IN_3,HIGH);
		M_PinWrite(IN_4,LOW);
		_delay_ms(10);
		
		M_PinWrite(IN_1,LOW);
		M_PinWrite(IN_2,LOW);
		M_PinWrite(IN_3,LOW);
		M_PinWrite(IN_4,HIGH);
		_delay_ms(10);
		M_PinWrite(IN_4,LOW);
	}
	
}