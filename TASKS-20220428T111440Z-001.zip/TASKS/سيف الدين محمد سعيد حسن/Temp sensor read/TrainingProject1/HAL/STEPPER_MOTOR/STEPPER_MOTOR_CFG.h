/*
 * STEPPER_MOTOR_CFG.h
 *
 * Created: 4/19/2022 9:44:25 AM
 *  Author: Saif Mohamed
 */ 


#ifndef STEPPER_MOTOR_CFG_H_
#define STEPPER_MOTOR_CFG_H_

#include "REG.h"

#define IN_1	PB2
#define IN_2	PB3
#define IN_3	PB4
#define IN_4	PB5



#endif /* STEPPER_MOTOR_CFG_H_ */