/*
 * STEPPER_MOTOR.h
 *
 * Created: 4/19/2022 9:44:14 AM
 *  Author: Saif Mohamed
 */ 


#ifndef STEPPER_MOTOR_H_
#define STEPPER_MOTOR_H_

#include "STD.h"

void H_StepperInit(void);
void H_StepperRotate(u32);


#endif /* STEPPER_MOTOR_H_ */