/*
 * PUSH_BUTTON_CFG.h
 *
 * Created: 4/18/2022 2:52:16 PM
 *  Author: Saif Mohamed
 */ 


#ifndef PUSH_BUTTON_CFG_H_
#define PUSH_BUTTON_CFG_H_

#define PUSH_BUTTON_1_PIN      PD2
#define PUSH_BUTTON_2_PIN      PD3
#define PUSH_BUTTON_3_PIN      PD4
#define PUSH_BUTTON_4_PIN      PD5

#endif /* PUSH_BUTTON_CFG_H_ */