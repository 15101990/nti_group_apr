/*
 * PUSH_BUTTON.h
 *
 * Created: 4/18/2022 2:52:00 PM
 *  Author: Saif Mohamed
 */ 


#ifndef PUSH_BUTTON_H_
#define PUSH_BUTTON_H_

#include "STD.h"

void H_PushButtonInit(u8);
u8   H_PushButtonRead(u8);

#define PB_1        1
#define PB_2        2
#define PB_3        3
#define PB_4        4

#define    PRESSED         0
#define    RELEASED        1



#endif /* PUSH_BUTTON_H_ */