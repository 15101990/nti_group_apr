/*
 * TEMP_CFG.h
 *
 * Created: 4/14/2022 5:46:59 AM
 *  Author: Saif Mohamed
 */ 


#ifndef TEMP_CFG_H_
#define TEMP_CFG_H_





#endif /* TEMP_CFG_H_ */