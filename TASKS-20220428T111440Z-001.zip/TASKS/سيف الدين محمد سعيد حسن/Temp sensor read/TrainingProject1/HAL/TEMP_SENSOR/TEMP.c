/*
 * TEMP.c
 *
 * Created: 4/14/2022 5:46:43 AM
 *  Author: Saif Mohamed
 */ 

#include "TEMP.h"
#include "ADC.h"
void H_TempSensorInit(void)
{
	M_AdcInit();
}
u16 H_TempSensorRead(void)
{
	u16 u16_loacal_adc_reading = M_AdcRead();
	u16 u16_local_temp = ((u32)u16_loacal_adc_reading * 500)/1023;
	return u16_local_temp;
}