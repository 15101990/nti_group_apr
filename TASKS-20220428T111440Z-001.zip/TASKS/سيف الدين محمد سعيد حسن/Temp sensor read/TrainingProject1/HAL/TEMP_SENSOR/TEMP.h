/*
 * TEMP.h
 *
 * Created: 4/14/2022 5:46:51 AM
 *  Author: Saif Mohamed
 */ 


#ifndef TEMP_H_
#define TEMP_H_
#include "STD.h"

void H_TempSensorInit(void);
u16 H_TempSensorRead(void);




#endif /* TEMP_H_ */