﻿/*
 * DC_MOTOR_CFG.h
 *
 * Created: 18/04/2022 09:43:28 ص
 *  Author: dell
 */ 


#ifndef DC_MOTOR_CFG_H_
#define DC_MOTOR_CFG_H_

#define IN_1       PB0
#define IN_2       PB1



#endif /* DC_MOTOR_CFG_H_ */