/*
 * BUZZER.h
 *
 * Created: 4/6/2022 10:57:10 AM
 *  Author: Saif Mohamed
 */ 


#ifndef BUZZER_H_
#define BUZZER_H_
#include "STD.h"

#include "DIO.h"
#define BUZZER_PIN PC5

void H_BuzzerInit(void);
void H_BuzzerShortBeeb(void);
void H_BuzzerDoubleShortBeeb(void);
void H_BuzzerLongBeeb(void);
void H_BuzzerTribleShortBeeb(void);
void H_BuzzerTog(void);
void H_BuzzerOff(void);
void H_BuzzerOn(void);


#endif /* BUZZER_H_ */