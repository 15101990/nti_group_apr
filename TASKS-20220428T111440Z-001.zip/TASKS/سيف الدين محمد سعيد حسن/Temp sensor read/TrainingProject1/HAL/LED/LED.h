/*
 * LED.h
 *
 * Created: 4/6/2022 12:24:47 AM
 *  Author: Saif Mohamed
 */ 


#ifndef LED_H_
#define LED_H_

#include "STD.h"

void H_LedInit(u8);
void H_LedOn(u8);
void H_LedOff(u8);
void H_LedTog(u8 u8_led);
void H_LedBlink(u8);

#define R_LED      1
#define G_LED      2
#define B_LED      3

#endif /* LED_H_ */