/*
 * LED_CFG.h
 *
 * Created: 4/6/2022 12:25:37 AM
 *  Author: Saif Mohamed
 */ 


#ifndef LED_CFG_H_
#define LED_CFG_H_

#define R_LED_PIN      PC0
#define G_LED_PIN      PC1
#define B_LED_PIN      PC2

#endif /* LED_CFG_H_ */