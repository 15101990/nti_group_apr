﻿/*
 * RELAY_CFG.h
 *
 * Created: 04/04/2022 02:12:28 م
 *  Author: dell
 */ 


#ifndef RELAY_CFG_H_
#define RELAY_CFG_H_





#endif /* RELAY_CFG_H_ */