﻿/*
 * SERVO_CFG.h
 *
 * Created: 19/04/2022 02:00:37 م
 *  Author: dell
 */ 


#ifndef SERVO_CFG_H_
#define SERVO_CFG_H_





#endif /* SERVO_CFG_H_ */