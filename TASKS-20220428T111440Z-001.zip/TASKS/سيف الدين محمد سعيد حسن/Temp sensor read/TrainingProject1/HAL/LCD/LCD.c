/*
 * LCD.c
 *
 * Created: 4/9/2022 6:19:20 AM
 *  Author: Saif Mohamed
 */ 
#include "LCD_CFG.h"
#include "LCD.h"
#include "DIO.h"
#include <stdio.h>

# define F_CPU 16000000UL
#include <util/delay.h>

void H_LcdInit(void)
{
	
	M_PinMode(LCD_RS_PIN,OUTPUT);
	M_PinMode(LCD_EN_PIN,OUTPUT);
	H_LcdWriteCommand(0x28);
	//M_PinMode(LCD_RW_PIN,OUTPUT);
	#if LCD_MODE     ==   _8_BIT_MODE
		M_PinMode(LCD_DATA_PIN_0,OUTPUT);
		M_PinMode(LCD_DATA_PIN_1,OUTPUT);
		M_PinMode(LCD_DATA_PIN_2,OUTPUT);
		M_PinMode(LCD_DATA_PIN_3,OUTPUT);
		M_PinMode(LCD_DATA_PIN_4,OUTPUT);
		M_PinMode(LCD_DATA_PIN_5,OUTPUT);
		M_PinMode(LCD_DATA_PIN_6,OUTPUT);
		M_PinMode(LCD_DATA_PIN_7,OUTPUT);

		_delay_ms(500);
		H_LcdWriteCommand(0x38);    // to select 8-bit mode
		H_LcdWriteCommand(0x0C);    // to turn display on , cursor off
		H_LcdWriteCommand(0x02);    // to return home
		H_LcdWriteCommand(0x06);    // to display from left to right
		H_LcdWriteCommand(0x01);    // to clear LCD
	#elif LCD_MODE    ==   _4_BIT_MODE
		M_PinMode(LCD_DATA_PIN_4,OUTPUT);
		M_PinMode(LCD_DATA_PIN_5,OUTPUT);
		M_PinMode(LCD_DATA_PIN_6,OUTPUT);
		M_PinMode(LCD_DATA_PIN_7,OUTPUT);
		_delay_ms(500);
		H_LcdWriteCommand(0x33);
		H_LcdWriteCommand(0x32);
		H_LcdWriteCommand(0x28);
		H_LcdWriteCommand(0x0C);    // to turn display on , cursor off
		H_LcdWriteCommand(0x02);    // to return home
		H_LcdWriteCommand(0x06);    // to display from left to right
		H_LcdWriteCommand(0x01);    // to clear LCD
	#endif
	
}
void H_LcdWriteCharacter(u8 u8_Local_Character)
{
	M_PinWrite(LCD_RS_PIN,HIGH);
	//M_PinWrite(LCD_RW_PIN,LOW);
	#if LCD_MODE    ==  _8_BIT_MODE
		LCD_DATA_REGISTER = u8_Local_Character;
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
	#elif LCD_MODE    ==   _4_BIT_MODE
		LCD_DATA_REGISTER = ((u8_Local_Character >> 1 & 0b01111000) | (LCD_DATA_REGISTER & 0b10000111));
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
		LCD_DATA_REGISTER = ((u8_Local_Character << 3) | (LCD_DATA_REGISTER & 0b10000111));
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
	#endif
}
void H_LcdWriteCommand(u8 u8_Local_Command)
{
	
	M_PinWrite(LCD_RS_PIN,LOW);
	//M_PinWrite(LCD_RW_PIN,LOW);
	#if LCD_MODE    ==   _8_BIT_MODE
		LCD_DATA_REGISTER = u8_Local_Command;
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
	#elif LCD_MODE    ==   _4_BIT_MODE
		LCD_DATA_REGISTER = ((u8_Local_Command >> 1 & 0b01111000) | (LCD_DATA_REGISTER & 0b10000111));
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
		LCD_DATA_REGISTER = ((u8_Local_Command << 3) | (LCD_DATA_REGISTER & 0b10000111));
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
	#endif
}
void H_LcdWriteString(u8* u8_Local_Ptr)
{
	u8 u8_local_counter = 0;
	while(u8_Local_Ptr[u8_local_counter] != '\0') 
	{
		H_LcdWriteCharacter(u8_Local_Ptr[u8_local_counter]);
		u8_local_counter++;
	}
}
void H_LcdWriteNumber(f64 f64_Local_Number)
{
		s32 s32_local_number_copy = f64_Local_Number;
		u8 u8_local_arr [10] = {0};
		u8 u8_local_dec_arr [LCD_FLOAT_PERCISION] = {0};	
		s8 s8_local_counter = 0;
		f64_Local_Number = f64_Local_Number - s32_local_number_copy;
		if(s32_local_number_copy == 0)
		{
			H_LcdWriteCharacter('0');
		}
		else if(s32_local_number_copy < 0)
		{
			H_LcdWriteCharacter('-');
			s32_local_number_copy = s32_local_number_copy * (-1);
			f64_Local_Number = f64_Local_Number * -1;
		}
		while(s32_local_number_copy != 0)
		{
			u8_local_arr [s8_local_counter] = s32_local_number_copy % 10;
			s8_local_counter++;
			s32_local_number_copy = s32_local_number_copy / 10;
		}
		s8_local_counter--;
		while (s8_local_counter >= 0)
		{
			H_LcdWriteCharacter(u8_local_arr[s8_local_counter] + '0');
			s8_local_counter--;
		}
		if (f64_Local_Number == 0)
		{
			
		}
		else
		{	
			H_LcdWriteCharacter('.');
			s8_local_counter++;
			for(s8_local_counter;s8_local_counter<LCD_FLOAT_PERCISION;s8_local_counter++)
			{
				f64_Local_Number = f64_Local_Number * 10;
				u8_local_dec_arr[s8_local_counter] = f64_Local_Number;
				f64_Local_Number = f64_Local_Number - u8_local_dec_arr[s8_local_counter];
				H_LcdWriteCharacter(u8_local_dec_arr[s8_local_counter] + '0');
			}

		}
		
	
		
}
/*void H_LcdWriteFloatNumber(f64 f64_Local_Number)
{
	s32 s32_local_number_copy = f64_Local_Number;
	H_LcdWriteNumber(s32_local_number_copy);
	H_LcdWriteCharacter('.');
	if (f64_Local_Number < 0)
	{
		f64_Local_Number = f64_Local_Number * -1;
		s32_local_number_copy = s32_local_number_copy * -1;
	}
	f64_Local_Number = f64_Local_Number - s32_local_number_copy;

	while (f64_Local_Number)
	{
		f64_Local_Number = f64_Local_Number * 10;
		s32_local_number_copy = f64_Local_Number;
		f64_Local_Number = f64_Local_Number - s32_local_number_copy;
		H_LcdWriteNumber(s32_local_number_copy);
	}
}*/
void H_LcdClear(void)
{
	H_LcdWriteCommand(0x01);//0x01 is a command registered in LCD ROM and LCD_MC will interpret it.
}
void H_LcdGoTo(u8 u8_local_row,u8 u8_local_col)
{
	u8 arr[2] = {0x80,0xC0};
	H_LcdWriteCommand(arr[u8_local_row]+u8_local_col);
}