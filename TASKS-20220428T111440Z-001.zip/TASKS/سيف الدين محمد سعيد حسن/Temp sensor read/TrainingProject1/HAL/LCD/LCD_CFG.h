/*
 * LCD_CFG.h
 *
 * Created: 4/9/2022 6:18:47 AM
 *  Author: Saif Mohamed
 */ 


#ifndef LCD_CFG_H_
#define LCD_CFG_H_
#include "REG.h"

#define LCD_MODE _4_BIT_MODE //You can choose _4_BIT_MODE or _8_BIT_MODE

#define LCD_DATA_REGISTER	    PORTA

/*#define LCD_DATA_PIN_0		PA0
#define LCD_DATA_PIN_1		    PA1
#define LCD_DATA_PIN_2			PA2
#define LCD_DATA_PIN_3			PA3*/
#define LCD_DATA_PIN_4			PA3
#define LCD_DATA_PIN_5			PA4
#define LCD_DATA_PIN_6			PA5
#define LCD_DATA_PIN_7			PA6
#define LCD_RS_PIN				PA1
#define LCD_RW_PIN	            PB2
#define LCD_EN_PIN	            PA2




#endif /* LCD_CFG_H_ */