/*
 * LCD.h
 *
 * Created: 4/9/2022 6:19:02 AM
 *  Author: Saif Mohamed
 */ 


#ifndef LCD_H_
#define LCD_H_

#include "STD.h"

#define LCD_FLOAT_PERCISION 2

void H_LcdInit(void);
void H_LcdWriteCharacter(u8);
void H_LcdWriteCommand(u8 u8_Local_Command);
void H_LcdWriteString(u8* u8_Local_Ptr);
void H_LcdWriteNumber(f64 f64_Local_Number);
void H_LcdWriteFloatNumber(f64 f64_Local_Number);
void H_LcdClear(void);
void H_LcdGoTo(u8 ,u8);

#define _4_BIT_MODE       4
#define _8_BIT_MODE       8

#endif /* LCD_H_ */