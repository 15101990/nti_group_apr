/*
 * UART.h
 *
 * Created: 4/20/2022 10:47:51 AM
 *  Author: Saif Mohamed
 */ 


#ifndef UART_H_
#define UART_H_

#include "STD.h"

void M_UartInit();
void M_UartSend(u8);
u8 M_UartReceive();

#define OFF		0
#define EVEN	1
#define ODD		2

#endif /* UART_H_ */