/*
 * SPI_CFG.h
 *
 * Created: 4/21/2022 10:27:59 AM
 *  Author: Saif Mohamed
 */ 


#ifndef SPI_CFG_H_
#define SPI_CFG_H_

//choose if the MC is MASTER or SLAVE
#define SPI_MODE MASTER

#define SS		PB4
#define MOSI	PB5
#define MISO	PB6
#define SCK		PB7


#endif /* SPI_CFG_H_ */