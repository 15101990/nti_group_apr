/*
 * SPI.h
 *
 * Created: 4/21/2022 10:27:48 AM
 *  Author: Saif Mohamed
 */ 


#ifndef SPI_H_
#define SPI_H_

#include "STD.h"

void M_SpiInit(void);
u8 M_SpiTransive(u8 u8_local_data);

#define MASTER     1
#define SLAVE      2
#endif /* SPI_H_ */