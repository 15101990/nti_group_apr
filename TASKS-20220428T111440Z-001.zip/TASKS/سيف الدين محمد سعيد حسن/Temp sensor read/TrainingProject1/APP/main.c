/*
 * TrainingProject1.c
 *
 * Created: 4/6/2022 12:17:17 AM
 * Author : Saif Mohamed
 */ 

#include "STD.h"
#include "KEY_PAD.h"
#include "LCD.h"
#include "LED.h"
#include "WATCHDOG.h"
#include "TIMER_0.h"
#include "PUSH_BUTTON_CFG.h"
#include "PUSH_BUTTON.h"
#include "EXAM.h"
#include "TEMP_CONTROL.h"
#include "ADC.h"

# define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	TempReadInit();
	while(1)
	{
		TempRead();
		LcdDisplay();
		ButtonRead();
		TempAlarm();
		TempCount();
	}
}


