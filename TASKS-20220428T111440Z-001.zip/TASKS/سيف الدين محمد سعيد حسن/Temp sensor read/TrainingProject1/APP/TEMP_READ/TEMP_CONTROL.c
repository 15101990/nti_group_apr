/*
 * TEMP_CONTROL.c
 *
 * Created: 4/26/2022 9:38:28 AM
 *  Author: Saif Mohamed
 */ 
#include "STD.h"
#include "TEMP_CONTROL.h"
#include "BUZZER.h"
#include "LED.h"
#include "PUSH_BUTTON.h"
#include "LCD.h"
#include "TEMP.h"
#include "BIT_MATH.h"

# define F_CPU 16000000UL
#include <util/delay.h>

u16 u16_global_temprature = 0;
u8  u8_global_alarm_state = 0;
u8  u8_global_buzzer_state = 0;
u8  u8_global_led_state = 0;


void TempReadInit(void)
{
	H_LedInit(R_LED);
	H_LedInit(B_LED);
	H_LedInit(G_LED);
	H_BuzzerInit();
	H_LcdInit();
	H_PushButtonInit(PB_1);
	H_PushButtonInit(PB_2);
	H_PushButtonInit(PB_3);
	H_TempSensorInit();
}


void LcdDisplay(void)
{
	H_LcdGoTo(0,0);
	H_LcdWriteString("Temp = ");
	u16_global_temprature = H_TempSensorRead();
	H_LcdWriteNumber(u16_global_temprature);
	H_LcdGoTo(1,0);
	if (u8_global_alarm_state == 0)
	{
		H_LcdWriteString("Alarm is On");
	}
	else
	{
		H_LcdWriteString("Alarm is Off");
	}
}

void TempRead(void)
{
	if (u8_global_led_state == 0)
	{
		if ((u16_global_temprature >= 100) && (u16_global_temprature < 200))
		{
			H_LedOn(B_LED);
			H_LedOff(G_LED);
			H_LedOff(R_LED);
		}
		else if ((u16_global_temprature >= 200) && (u16_global_temprature < 300))
		{
			H_LedOn(B_LED);
			H_LedOn(G_LED);
			H_LedOff(R_LED);
		}
		else if ((u16_global_temprature >= 300) && (u16_global_temprature < 400))
		{
			H_LedOn(R_LED);
			H_LedOn(B_LED);
			H_LedOn(G_LED);
		}
		else if (u16_global_temprature >= 400)
		{
			H_LedTog(B_LED);
			H_LedTog(G_LED);
			H_LedTog(R_LED);
			_delay_ms(200);
		}
		else
		{
			
		}
	}
	else
	{
		H_LedOff(B_LED);
		H_LedOff(G_LED);
		H_LedOff(R_LED);
	}
}

void ButtonRead(void)
{
	u8 u8_local_PB_count = 1;
	for (u8_local_PB_count = PB_1 ; u8_local_PB_count <= PB_3 ; u8_local_PB_count++)
	{
		u8 u8_local_read = H_PushButtonRead(u8_local_PB_count);
		if (u8_local_read == PRESSED)
		{
			_delay_ms(30);
			u8_local_read = H_PushButtonRead(u8_local_PB_count);
			if (u8_local_read == PRESSED)
			{
				while ( H_PushButtonRead(u8_local_PB_count) == PRESSED);
				switch(u8_local_PB_count)
				{
					case 1:
					TOG_BIT(u8_global_led_state,0);
					break;
					case 2:
					TOG_BIT(u8_global_buzzer_state,0);
					break;
					case 3:
					TOG_BIT(u8_global_alarm_state,0);
					default:
					break;
				}
			}
		}
	}
}

void TempAlarm(void)
{
	if ((u8_global_alarm_state == 0) && (u8_global_buzzer_state == 0))
	{
		if (u16_global_temprature >= 450)
		{
			H_BuzzerOn();
			_delay_ms(80);
			H_BuzzerOff();
			_delay_ms(500);
		}
	}
}

void TempCount(void)
{
	static u16 u16_static_local_counter = 50;
	if (u16_static_local_counter <= 500)
	{
		if ((u16_global_temprature >= u16_static_local_counter) && (u16_global_temprature < u16_static_local_counter + 50))
		{
			H_BuzzerDoubleShortBeeb();
			u16_static_local_counter = u16_static_local_counter + 50; 
		}
	}
	else
	{
		u16_static_local_counter = 50;
	}
}

