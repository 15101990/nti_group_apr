/*
 * TEMP_CONTROL.h
 *
 * Created: 4/26/2022 9:38:43 AM
 *  Author: Saif Mohamed
 */ 


#ifndef TEMP_CONTROL_H_
#define TEMP_CONTROL_H_


void TempReadInit(void);
void LcdDisplay(void);
void TempRead(void);
void ButtonRead(void);
void TempAlarm(void);
void TempCount(void);



#endif /* TEMP_CONTROL_H_ */