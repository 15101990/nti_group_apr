/*
 * GccApplication1.c
 *
 * Created: 03/04/2022 10:07:52 ص
 * Author : dell
 */ 
#include "BIT_MATH.h"
#include "REG.h"
#include "STD.h"
#include "DIO.h"
#include "LED.h"
#include "P_B.h"
#include "SSD.h"
#include "KEY_PAD.h"
#include "LCD.h"
#include "EXT_INT.h"
#include "TEMP.h"
#include "TIMER_0.h"
#include "TIMER_1.h"
#include "STEPPER.h"
#include "DC_MOTOR.h"
#include "WDT.h"
#include "SERVO.h"
#include "UART.h"
#include "SPI.h"
#include "BUZZER.h"
#include "AT24C16A.h"
void EXT_INT_EXC(void);
void TIMER_0_EXC(void);
void Led_Control (u16 Temp);
void Buzzer_Check(u16 Temp);
#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{
	u16 Temp_val = 0;
	u8 read_1 = 0;
	u8 flag_1 = 0;
	H_LcdInit();
	H_TempSensorInit();
	H_LedInit(B_LED);
	H_LedInit(G_LED);
	H_LedInit(R_LED);
	H_PushButtonInit(PB_1);
	H_PushButtonInit(PB_2);
	H_PushButtonInit(PB_3);
	H_BuzzerInit();
	while(1)
	{
		Temp_val = H_TempSensorRead();
		read_1 = H_PushButtonRead(PB_1);
		if(read_1 == 1)
		{
			flag_1 = 0;
			_delay_ms(100);
			read_1 = H_PushButtonRead(PB_1) ;
			while(read_1 == 1);
			flag_1 ^= 1 ;
			if(flag_1 == 1)
			{
				H_LedOff(B_LED);
				H_LedOff(R_LED);
				H_LedOff(G_LED);
			}			
		}
		Led_Control(Temp_val);
		Buzzer_Check (Temp_val);
		H_LcdWriteNumber(Temp_val);
		_delay_ms(500);
		H_LcdClear();
	}
}
void EXT_INT_EXC(void)
{
	H_LedOn(R_LED);
}
void TIMER_0_EXC(void)
{
	H_LedTog(R_LED);
}
void Led_Control (u16 Temp) 
{
	if (Temp >= 400)
	{
		H_LedOn(B_LED);
		H_LedOn(R_LED);
		H_LedOn(G_LED);
		_delay_ms(200);
		H_LedOff(B_LED);
		H_LedOff(R_LED);
		H_LedOff(G_LED);
		_delay_ms(200);
	}
	else if (Temp >= 300)
	{
		H_LedOn(B_LED);
		H_LedOn(R_LED);
		H_LedOn(G_LED);
	}
	else if(Temp >=200)
	{
		H_LedOn(B_LED);
		H_LedOn(G_LED);
	}
	else if(Temp >= 100)
	{
		H_LedOn(B_LED);
	}
	else if(Temp < 100 )
	{
		H_LedOff(B_LED);
		H_LedOff(R_LED);
		H_LedOff(G_LED);
	}
}
void Buzzer_Check (u16 Temp)
{
	if((Temp %50) == 0)
	{
		H_BuzzerOnce();
	}
}
