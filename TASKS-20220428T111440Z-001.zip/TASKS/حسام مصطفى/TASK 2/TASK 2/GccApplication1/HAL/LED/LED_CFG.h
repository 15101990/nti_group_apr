﻿/*
 * LED_CFG.h
 *
 * Created: 04/04/2022 09:58:32 ص
 *  Author: dell
 */ 


#ifndef LED_CFG_H_
#define LED_CFG_H_

#define R_LED_PIN      PC0
#define G_LED_PIN      PC1
#define B_LED_PIN      PC2

#endif /* LED_CFG_H_ */