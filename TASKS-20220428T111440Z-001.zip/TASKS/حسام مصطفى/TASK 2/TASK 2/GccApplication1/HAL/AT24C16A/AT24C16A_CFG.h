﻿/*
 * AT24C16A_CFG.h
 *
 * Created: 25/04/2022 11:43:25 ص
 *  Author: dell
 */ 


#ifndef AT24C16A_CFG_H_
#define AT24C16A_CFG_H_





#endif /* AT24C16A_CFG_H_ */