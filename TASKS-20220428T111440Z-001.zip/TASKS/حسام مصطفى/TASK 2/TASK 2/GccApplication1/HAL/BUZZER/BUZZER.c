/*
 * BUZZER.c
 *
 * Created: 06/04/2022 11:53:04
 *  Author: khaled
 */ 

#include "BUZZER.h"

void H_BuzzerInit ()
{
	M_PinMode(BUZZER_PIN,OUTPUT);
}
void H_BuzzerOnce ()
{
	M_PinWrite(BUZZER_PIN,HIGH);
	_delay_ms(500);
	M_PinWrite(BUZZER_PIN,LOW);
}
