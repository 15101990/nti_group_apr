/*
 * BUZZER.h
 *
 * Created: 06/04/2022 11:54:01
 *  Author: khaled
 */ 


#ifndef BUZZER_H_
#define BUZZER_H_

/***************INCLUDES**********/

#include "STD.h"
#include "BUZZER_CFG.h"
#include "DIO.h"
# define F_CPU 16000000UL
#include <util/delay.h>

/**************PROTOTYPES**********/

void H_BuzzerInit ();
void H_BuzzerOnce ();


#endif /* BUZZER_H_ */