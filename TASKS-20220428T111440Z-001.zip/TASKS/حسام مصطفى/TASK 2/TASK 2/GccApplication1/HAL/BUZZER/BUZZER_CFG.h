/*
 * BUZZER_CFG.h
 *
 * Created: 06/04/2022 11:55:30
 *  Author: khaled
 */ 


#ifndef BUZZER_CFG_H_
#define BUZZER_CFG_H_


#define BUZZER_PIN     PC5


#endif /* BUZZER_CFG_H_ */