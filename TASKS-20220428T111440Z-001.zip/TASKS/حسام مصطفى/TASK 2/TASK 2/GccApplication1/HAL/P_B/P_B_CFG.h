﻿/*
 * P_B_CFG.h
 *
 * Created: 04/04/2022 10:42:55 ص
 *  Author: dell
 */ 


#ifndef P_B_CFG_H_
#define P_B_CFG_H_


#define PUSH_BUTTON_1_PIN      PD2
#define PUSH_BUTTON_2_PIN      PD3
#define PUSH_BUTTON_3_PIN      PD4
#define PUSH_BUTTON_4_PIN      PD5

#endif /* P_B_CFG_H_ */