﻿/*
 * STEPPER.h
 *
 * Created: 19/04/2022 09:43:01 ص
 *  Author: dell
 */ 


#ifndef STEPPER_H_
#define STEPPER_H_

#include "STD.h"

void H_StepperInit(void);
void H_StepperRotate(u32);

#endif /* STEPPER_H_ */