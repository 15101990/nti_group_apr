﻿/*
 * STEPPER_CFG.h
 *
 * Created: 19/04/2022 09:43:12 ص
 *  Author: dell
 */ 


#ifndef STEPPER_CFG_H_
#define STEPPER_CFG_H_

#define IN_1       PB2
#define IN_2       PB3
#define IN_3       PB4
#define IN_4       PB5



#endif /* STEPPER_CFG_H_ */