﻿/*
 * WDT_CFG.h
 *
 * Created: 19/04/2022 10:52:43 ص
 *  Author: dell
 */ 


#ifndef WDT_CFG_H_
#define WDT_CFG_H_





#endif /* WDT_CFG_H_ */