﻿/*
 * WDT.h
 *
 * Created: 19/04/2022 10:52:33 ص
 *  Author: dell
 */ 


#ifndef WDT_H_
#define WDT_H_

void M_WdtInit(void);
void M_WdtRefresh(void);

#endif /* WDT_H_ */