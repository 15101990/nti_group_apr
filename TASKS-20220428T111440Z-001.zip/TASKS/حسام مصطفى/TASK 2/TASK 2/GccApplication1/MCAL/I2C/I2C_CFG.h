﻿/*
 * I2C_CFG.h
 *
 * Created: 24/04/2022 01:05:26 م
 *  Author: dell
 */ 


#ifndef I2C_CFG_H_
#define I2C_CFG_H_

// I2C_MODE options --> [ MASTER , SLAVE ]
#define I2C_MODE     MASTER




#endif /* I2C_CFG_H_ */