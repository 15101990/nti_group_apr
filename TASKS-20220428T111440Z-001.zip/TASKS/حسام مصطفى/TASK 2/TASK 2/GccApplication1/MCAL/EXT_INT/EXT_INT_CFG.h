﻿/*
 * EXT_INT_CFG.h
 *
 * Created: 11/04/2022 10:07:10 ص
 *  Author: dell
 */ 


#ifndef EXT_INT_CFG_H_
#define EXT_INT_CFG_H_

// SENSE_CONTROL options -> [ FAILLING_EDGE , RISING_EDGE , ANY_LOGICAL_CHANGE , LOW_LEVEL ]
#define SENSE_CONTROL     FAILLING_EDGE


#endif /* EXT_INT_CFG_H_ */