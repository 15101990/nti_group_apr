﻿/*
 * TEMP_CFG.h
 *
 * Created: 12/04/2022 01:41:34 م
 *  Author: dell
 */ 


#ifndef TEMP_CFG_H_
#define TEMP_CFG_H_





#endif /* TEMP_CFG_H_ */