﻿/*
 * TEMP.h
 *
 * Created: 12/04/2022 01:41:23 م
 *  Author: dell
 */ 


#ifndef TEMP_H_
#define TEMP_H_
#include "STD.h"


void H_TempSensorInit(void);
u16  H_TempSensorRead(void);



#endif /* TEMP_H_ */