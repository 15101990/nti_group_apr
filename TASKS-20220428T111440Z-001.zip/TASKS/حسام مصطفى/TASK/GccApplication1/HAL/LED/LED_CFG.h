﻿/*
 * LED_CFG.h
 *
 * Created: 04/04/2022 09:58:32 ص
 *  Author: dell
 */ 


#ifndef LED_CFG_H_
#define LED_CFG_H_
#define PROTEUS

#if defined (PROTEUS)
#define R_LED_PIN      PB0
#define G_LED_PIN      PB1
#define B_LED_PIN      PB2

#elif defined (KIT)
#define R_LED_PIN      PA6
#define G_LED_PIN      PA4
#define B_LED_PIN      PA5
#endif
#endif /* LED_CFG_H_ */