﻿/*
 * KEY_PAD.h
 *
 * Created: 10/04/2022 10:18:33 ص
 *  Author: dell
 */ 


#ifndef KEY_PAD_H_
#define KEY_PAD_H_

#include "STD.h"

void H_KeyPadInit(void);
u8   H_KeyPadRead(void);



#endif /* KEY_PAD_H_ */