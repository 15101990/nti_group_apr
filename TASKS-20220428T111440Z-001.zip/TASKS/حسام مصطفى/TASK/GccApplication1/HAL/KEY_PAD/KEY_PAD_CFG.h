﻿/*
 * KEY_PAD_CFG.h
 *
 * Created: 10/04/2022 10:18:45 ص
 *  Author: dell
 */ 


#ifndef KEY_PAD_CFG_H_
#define KEY_PAD_CFG_H_

#define KEY_PAD_R0     PB4
#define KEY_PAD_R1     PB5
#define KEY_PAD_R2     PB6
#define KEY_PAD_R3     PB7

#define KEY_PAD_C0     PD2
#define KEY_PAD_C1     PD3
#define KEY_PAD_C2     PD4
#define KEY_PAD_C3     PD5



#endif /* KEY_PAD_CFG_H_ */