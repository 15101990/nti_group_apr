/*
 * LCD.c
 *
 * Created : 19/04/2022 
 * Version : 2
 * Author  : HOSSAM
 */ 
#include "LCD.h"

void H_LcdInit(void)
{
	M_PinMode(LCD_RS_PIN,OUTPUT);
	M_PinMode(LCD_EN_PIN,OUTPUT);
	#if LCD_MODE == _8_BIT_MODE
	    M_PinMode(LCD_DATA_PIN_0,OUTPUT);
	    M_PinMode(LCD_DATA_PIN_1,OUTPUT);
	    M_PinMode(LCD_DATA_PIN_2,OUTPUT);
	    M_PinMode(LCD_DATA_PIN_3,OUTPUT);
	    M_PinMode(LCD_DATA_PIN_4,OUTPUT);
	    M_PinMode(LCD_DATA_PIN_5,OUTPUT);
	    M_PinMode(LCD_DATA_PIN_6,OUTPUT);
	    M_PinMode(LCD_DATA_PIN_7,OUTPUT);
	    		
	    _delay_ms(500);
	    H_LcdWriteCommand(_8_BIT_MODE_COMMAND);
	    H_LcdWriteCommand(DISPLAY_ON_CURSOR_OFF_COMMAND);
	    H_LcdWriteCommand(RETURN_HOME_COMMAND);
	    H_LcdWriteCommand(DISPLAY_LEFT_TO_RIGHT_COMMAND);
	    H_LcdWriteCommand(CLEAR_LCD_COMMAND);
		
	#elif LCD_MODE == _4_BIT_MODE
		M_PinMode(LCD_DATA_PIN_4,OUTPUT);
		M_PinMode(LCD_DATA_PIN_5,OUTPUT);
		M_PinMode(LCD_DATA_PIN_6,OUTPUT);
		M_PinMode(LCD_DATA_PIN_7,OUTPUT);
		
		_delay_ms(500);
		
		// [COMMAND_1 + COMMAND_2 + COMMAND_3] == 4 BIT MODE
		H_LcdWriteCommand(_4_BIT_MODE_COMMAND_1);
		H_LcdWriteCommand(_4_BIT_MODE_COMMAND_2);
		H_LcdWriteCommand(_4_BIT_MODE_COMMAND_3);
		
		H_LcdWriteCommand(DISPLAY_ON_CURSOR_OFF_COMMAND);
		H_LcdWriteCommand(RETURN_HOME_COMMAND);
		H_LcdWriteCommand(DISPLAY_LEFT_TO_RIGHT_COMMAND);
		H_LcdWriteCommand(CLEAR_LCD_COMMAND);			
	#endif 
}

void H_LcdWriteCommand(u8 command)
{
	//static u8 lcd_counter = 0 ;
	M_PinWrite(LCD_RS_PIN,LOW); // RS = 0 --> command 
	#if LCD_MODE == _8_BIT_MODE
	LCD_DATA_PORT = command; 
	M_PinWrite(LCD_EN_PIN,HIGH);
	_delay_ms(1);
	M_PinWrite(LCD_EN_PIN,LOW);
	_delay_ms(5); //?????
/*if(lcd_counter == 16)
{
	H_LCDGoTo(ROW_1,COL_1);
	H_LedInit(R_LED);
	H_LedOn(R_LED);
}*/
	#elif LCD_MODE == _4_BIT_MODE 
	      #if defined(PROTEUS)	 
	      LCD_DATA_PORT = (( (command >> 1) & 0x78) | (LCD_DATA_PORT & 0x87));
	      M_PinWrite(LCD_EN_PIN,HIGH);
	      _delay_ms(1);
	      M_PinWrite(LCD_EN_PIN,LOW);
	      _delay_ms(5);
	      LCD_DATA_PORT = (((command << 3) & 0x78)  | (LCD_DATA_PORT & 0x87));
	      M_PinWrite(LCD_EN_PIN,HIGH);
	      _delay_ms(1);
	      M_PinWrite(LCD_EN_PIN,LOW);
	      _delay_ms(5);
		  
		  #elif defined(KIT)
		  LCD_DATA_PORT = ((( (command >> 4) & 0x07) | ((command>>3) &0x10)) | (LCD_DATA_PORT & 0xE8));
		  M_PinWrite(LCD_EN_PIN,HIGH);
		  _delay_ms(1);
		  M_PinWrite(LCD_EN_PIN,LOW);
		  _delay_ms(5);
		  LCD_DATA_PORT = ( ( (command & 0x07) | ( (command<<1) &0x10) ) | (LCD_DATA_PORT & 0xE8) );
		  M_PinWrite(LCD_EN_PIN,HIGH);
		  _delay_ms(1);
		  M_PinWrite(LCD_EN_PIN,LOW);
		  _delay_ms(5);
		  #endif
	#endif
	//lcd_counter ++;
}
void H_LcdWriteChar(u8 character)
{
	M_PinWrite(LCD_RS_PIN,HIGH); // RS = 0 --> DATA

	#if LCD_MODE == _8_BIT_MODE 
		LCD_DATA_PORT = character;
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5); //?????
	
	#elif LCD_MODE == _4_BIT_MODE
		#if defined(PROTEUS)
		LCD_DATA_PORT = (( (character >> 1) & 0x78) | (LCD_DATA_PORT & 0x87));
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
		LCD_DATA_PORT = (((character << 3) & 0x78)  | (LCD_DATA_PORT & 0x87));
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
		
		#elif defined(KIT)
		LCD_DATA_PORT = ((( (character >> 4) & 0x07) | ((character>>3) &0x10)) | (LCD_DATA_PORT & 0xE8));
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
		LCD_DATA_PORT = ( ( (character & 0x07) | ( (character<<1) &0x10) ) | (LCD_DATA_PORT & 0xE8) );
		M_PinWrite(LCD_EN_PIN,HIGH);
		_delay_ms(1);
		M_PinWrite(LCD_EN_PIN,LOW);
		_delay_ms(5);
		#endif
	#endif
}

void H_LcdClear(void)
{
	H_LcdWriteCommand(CLEAR_LCD_COMMAND);
}

void H_LcdWriteString(u8 * ptr)
{
	while(*ptr != '\0')
	{
		H_LcdWriteChar(*ptr);
		ptr ++;
	}
}

void H_LcdWriteNumber(f64 local_number)
{
	s32 s32_local_number_copy = local_number;
	u8 u8_local_arr [10] = {0};
	s8 s8_local_counter = 0;
	if(s32_local_number_copy == 0)
	{
		H_LcdWriteChar('0');
	}
	else if(s32_local_number_copy < 0)
	{
		H_LcdWriteChar('-');
		s32_local_number_copy = s32_local_number_copy * (-1);
	}
	while(s32_local_number_copy != 0)
	{
		u8_local_arr [s8_local_counter] = s32_local_number_copy % 10;
		s8_local_counter++;
		s32_local_number_copy = s32_local_number_copy / 10;
	}
	s8_local_counter--;
	while (s8_local_counter >= 0)
	{
		H_LcdWriteChar(u8_local_arr[s8_local_counter] + '0');
		s8_local_counter--;
	}
}

void H_LCDGoTo(u8 row_position,u8 col_position)
{
	switch (row_position)
	{
		case ROW_0 :
		H_LcdWriteCommand(ROW_0_HOME + col_position);
		break;
		case ROW_1 :
		H_LcdWriteCommand(ROW_1_HOME + col_position);
		break;
		#if defined(KIT)
		case ROW_2 :
		H_LcdWriteCommand(ROW_2_HOME + col_position);
		break;
		case ROW_3 :
		H_LcdWriteCommand(ROW_3_HOME + col_position);
		break;
		#endif
		default:
		break;				
	}
}
void H_LcdStopWatchDisplay (u8 h , u8 m , u8 s)
{
	u8 m1 = 0 ;
	u8 m2 = 0 ;
	u8 s1 = 0 ;
	u8 s2 = 0 ;
	u8 h1 = 0 ;
	u8 h2 = 0 ; 
	s1 = s / 10 ;
	s2 = s % 10 ;
	m1 = m  / 10 ;
	m2 = m  % 10 ;
	h1 = h   / 10 ;
	h2 = h   % 10 ;
	H_LCDGoTo(ROW_0,COL_4);
	H_LcdWriteNumber(h1);
	H_LcdWriteNumber(h2);
	H_LcdWriteChar(':');
	H_LcdWriteNumber(m1);
	H_LcdWriteNumber(m2);
	H_LcdWriteChar(':');
	H_LcdWriteNumber(s1);
	H_LcdWriteNumber(s2);
}