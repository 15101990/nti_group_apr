/*
 * LCD.c
 *
 * Created : 19/04/2022 
 * Version : 2
 * Author  : HOSSAM
 */ 


#ifndef LCD_CFG_H_
#define LCD_CFG_H_

//LCD_MODE options --> [ _4_BIT_MODE , _8_BIT_MODE ] 
#define LCD_MODE				   _4_BIT_MODE

// options --> [proteus,kit]  
#define PROTEUS 						

#if defined (PROTEUS)
#define LCD_DATA_PORT			   PORTA

#define LCD_DATA_PIN_0             PB0
#define LCD_DATA_PIN_1             PB1
#define LCD_DATA_PIN_2             PB2
#define LCD_DATA_PIN_3             PB3

#define LCD_DATA_PIN_4             PA3
#define LCD_DATA_PIN_5             PA4
#define LCD_DATA_PIN_6             PA5
#define LCD_DATA_PIN_7             PA6

#define LCD_RS_PIN                 PA1
#define LCD_EN_PIN				   PA2


#elif defined(KIT)
#define LCD_DATA_PORT			   PORTB

#define LCD_DATA_PIN_4             PB0
#define LCD_DATA_PIN_5             PB1
#define LCD_DATA_PIN_6             PB2
#define LCD_DATA_PIN_7             PB4

#define LCD_RS_PIN                 PA3
#define LCD_EN_PIN				   PA2

#endif

#endif /* LCD_CFG_H_ */