/*
 * GccApplication1.c
 *
 * Created: 03/04/2022 10:07:52  
 * Author : dell
 */ 
//#include "APP.h"
#include "STD.h"
#include "DIO.h"
#include "LED.h"
#include "P_B.h"
#include "LCD.h"
#include "TIMER_0.h"
#include "TIMER_1.h"
#define F_CPU 16000000UL
#include <util/delay.h>
/******************PROTOTYPES ***********************/
void EXT_INT_EXC(void);
void TIMER_0_EXC(void);
void Asking (void);
void check_answer (u8 ,u8 *);
void Right_Answer (void);
void Wrong_Answer (void);

u8 second = 0;
u8 minut  = 0;
u8 hour	  = 0;
u8 question_flag = 0;
u8 question = 1;

int main(void)
{
	//H_LcdInit();
	//M_Timer0Init();
	H_PushButtonInit(PB_1);
	H_LedInit(B_LED);
	H_LedInit(R_LED);
	H_LedInit(G_LED);
	H_PushButtonInit(PB_2);
	H_PushButtonInit(PB_3);
	//H_PushButtonInit(PB_4);
	//M_Timer0SetTime(1000);
    //M_Timer0_SetCallBack(TIMER_0_EXC);
	//M_Timer0Start();
	while(1)
	{
		if(H_PushButtonRead(PB_1)==0)
		{
			_delay_ms(150);
			u8 reading = M_PinRead(PB_1);
			if(reading == PRESSED){
			while(M_PinRead(PB_1) == PRESSED);
			H_LedTog(B_LED);}
		}
		else if(H_PushButtonRead(PB_2)==0)
		{
			H_LedTog(G_LED);
		}
		else if(H_PushButtonRead(PB_3)==0)
		{
			H_LedTog(R_LED);
		}
		//Asking ();
		//H_LcdStopWatchDisplay(hour , minut ,second);
	}
}
/*void Asking ()
{
	u8 q1 = 0 ;
	u8 q2 = 0 ;
	H_LCDGoTo(ROW_1,COL_0);
	H_LcdWriteString("Q-");
	q1 = question / 10;
	q2 = question % 10;
	H_LcdWriteNumber(q1);
	H_LcdWriteNumber(q2);
	H_LCDGoTo(ROW_1,COL_8);
	H_LcdWriteString("A B C D");
	u8 push_button_flag[] = {0,0,0,0};
	for (u8 push_button = PB_1 ; push_button <= PB_4 ; push_button++)
	{
		u8 reading = RELEASED;
		reading = M_PinRead(push_button);
		if(reading == PRESSED)
		{
			_delay_ms(150);
			reading = M_PinRead(push_button);
			if(reading == PRESSED)
			{
				while(M_PinRead(push_button) == PRESSED);
				push_button_flag [push_button-1] = 1;
			}
		}
	}
	check_answer(question,push_button_flag);
}
void check_answer (u8 question,u8 ans[])
{
	switch(question)
	{
		case 1:
		if(ans[3] == 1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 2:
		if(ans[2] == 1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 3:
		if(ans[3] == 1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 4:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 5:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 6:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 7:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 8:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 9:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 10:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 11:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 12:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 13:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 14:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 15:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 16:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 17:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 18:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 19:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 20:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 21:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 22:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 23:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 24:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 25:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 26:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 27:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 28:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 29:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
		case 30:
		if(ans[3]==1)
		{
			Right_Answer ();
		}
		else
		{
			Wrong_Answer ();
		}
		break;
	}
}
void Right_Answer ()
{
	H_LcdWriteString("   ->GREAT<-    ");
	H_LCDGoTo(ROW_1,COL_0);
	H_LcdWriteString("                ");;
	_delay_ms(1000);
	question ++;
}
void Wrong_Answer ()
{
	H_LcdWriteString("      LOSER     ");
	H_LCDGoTo(ROW_1,COL_1);
	H_LcdWriteString("1 minute penalty");
	_delay_ms(1000);
	minut ++;
}

void TIMER_0_EXC(void)
{
	second ++;
	if(second>59)
	{
		second = 0;
		minut ++;
	}
	if(minut>59)
	{
		minut = 0;
		hour ++;
	}
}*/
