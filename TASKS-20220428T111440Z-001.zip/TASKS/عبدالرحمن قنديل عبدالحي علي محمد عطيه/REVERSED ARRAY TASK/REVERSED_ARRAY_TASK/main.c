/*
 * Version 1
 *
 * * program to Reverse Array of 10 Numbers User Entered it .
 *  Author: Abdelrahman
 */ 

#include <stdio.h>
#include "STD_TYPES.h"
#define size 10

void ReversedArray(u16*);
u16 main()
{
   u8 i;
   u16 arr[size] = {0};
   printf("\nPlease enter 10 Numbers :\n");

   for(i=0;i<size;i++)
   {
       scanf("%d",&arr[i]);
   }

printf("\n--------------------------------------------------\n");

ReversedArray(arr);

printf("\nReversedArray:\n");
    for(i=0;i<size; i++)
    {
        printf("\n%d\n",arr[i]);
    }

}

void ReversedArray(u16 pArr[])
{
 u8 i;
 u16 temp;
 for(i=0; i<size/2; i++)
    {
        temp = pArr[i];
        pArr[i] = pArr[size-i-1];
        pArr[size-i-1] = temp;
    }


}
