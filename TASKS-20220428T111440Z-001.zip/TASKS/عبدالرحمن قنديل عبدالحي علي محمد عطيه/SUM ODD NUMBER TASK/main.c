/*
 * Version 1
 *
 * * program to print the sum of all odd numbers from 1 to n Number user choose it .
 *  Author: Abdelrahman
 */ 


/*#include <stdio.h>
#include "STD_TYPES.h"
u16 main()
{
    u16 Counter , Number , Sum=0;

    // Input range to find sum of odd numbers 
    printf("Enter Upper limit Number : ");
    scanf("%d", &Number);

    //Find the sum of all odd number 
    for(Counter=1; Counter<=Number; Counter+=2)
    {
        Sum += Counter;
    }

    printf("Sum of odd numbers = %d", Sum);

    return 0;
}*/

/*
 * Version 2
 
 *   program to print the sum of all odd numbers in given range user choose it .
 **/ 


#include <stdio.h>
#include "STD_TYPES.h"
u16 main()
{
    u16 Counter, start, end, sum=0;

    // Input range to find sum of odd numbers 
    printf("Enter lower limit Number: ");
    scanf("%d", &start);
    printf("Enter upper limit Number: ");
    scanf("%d", &end);

    //If lower limit is even then make it odd 
    if(start % 2 == 0)
    {
        start++;
    }
    
    // Iterate from start to end and find sum 
    for(Counter=start; Counter<=end; Counter+=2)
    {
        sum += Counter;
    }

    printf("Sum of odd numbers between %d to %d = %d", start, end, sum);

    return 0;
}

