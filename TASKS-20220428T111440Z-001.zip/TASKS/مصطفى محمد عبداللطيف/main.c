/*V1*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 0; //
    printf("Please Enter number = ");
    scanf("%d",&x);
    if (x%2){x++;} //
    x = x/2; //
    x = x * x ;
    printf("The summation of odd numbers = %d",x); //

    return 0;
}




/*V2*

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float x = 0;
    printf("Please Enter number = ");
    scanf("%d",&x);
    x = round(x/2);
    x = x * x ;
    printf("The summation of odd numbers = %d",(int)x);

    return 0;
}
*/





