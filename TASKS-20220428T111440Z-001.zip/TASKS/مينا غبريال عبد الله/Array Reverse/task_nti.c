/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<stdio.h>
#define SIZE 10

void arr_rev(int *);

int main()
{
    int i = 0;
    int arr[SIZE];
    for(i=0; i<SIZE; i++)
    {
        scanf("%d", &arr[i]);
    }

    arr_rev(arr);

    printf("\nThe reversed array elements: \n");

    for(i=0; i<SIZE ; i++)
    {
        printf("%d\n", arr[i]);
    }
    return 0;
}

void arr_rev(int * ptr)
{
    int i=0;
    int arr[SIZE];
    for(i=0; i<SIZE; i++)
    {
        arr[SIZE-1-i] = ptr[i];
    }
    for(i=0; i<SIZE; i++)
    {
        ptr[i] = arr[i];
    }
}
