#include<stdio.h>

int main()
{
    int i = 1;
    int sum = 0;
    int num;

    printf("Enter a number: \n");
    scanf("%d", &num);

    for(i=1; i<=num; i=i+2)
    {
        sum = sum + i;
    }
    printf("The sum of odd numbers = %d\n", sum);
}
