
#include <stdio.h>

int main()
{
    int Counter , Num , Sum=0;

    
    printf("\nEnter limit Number : ");
    scanf("%d", &Num);

     
    for(Counter=1; Counter<=Num; Counter+=2)
    {
        Sum += Counter;
    }

    printf("\nSum of odd numbers = %d", Sum);

    return 0;
}

